from typing import Type, Annotated

from sqlalchemy.orm import Session

from fastapi import Request, Body, HTTPException

import models
from app import App
from decorators.security_decorators import privilege_level_required
from utils.users_util import get_dict_from_user_model


@App.post('/groups/group',
          summary='Создать новую группу',
          tags=['Группы'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def create_group(_request: Request,
                 name: str):
    with Session(models.engine) as session:
        group = models.Group(name=name)

        session.add(group)
        session.commit()

        return {'group_id': group.id}


@App.get('/groups/list',
         summary='Получить список всех групп',
         tags=['Группы'])
@privilege_level_required(minimal_level=models.UserType.Teacher)
def get_groups(_request: Request):
    with Session(models.engine) as session:
        groups: list[Type[models.Group]] = session.query(models.Group).all()

        return [{
            'id': group.id,
            'name': group.name
        } for group in groups]


@App.put('/groups/group',
         summary='Обновить имя группы',
         tags=['Группы'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def update_group_name(_request: Request,
                      group_id: Annotated[int, Body()],
                      name: Annotated[str, Body()]):
    with Session(models.engine) as session:
        group = session.query(models.Group).get(group_id)

        if group is None:
            raise HTTPException(status_code=400,
                                detail='Неправильный ID группы!')

        group.name = name

        session.commit()


@App.put('/groups/delete',
         summary='Удалить группу',
         tags=['Группы'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def delete_group(_request: Request,
                 group_id: Annotated[int, Body()]):
    with Session(models.engine) as session:
        session.query(models.Group).filter_by(id=group_id).delete()

        session.commit()

        return {'ok': True}


@App.post('/groups/user_groups',
          summary=['Добавить пользователя в группу'],
          tags=['Группы'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def add_user_to_group(_request: Request,
                      user_id: Annotated[int, Body()],
                      group_id: Annotated[int, Body()]):
    with Session(models.engine) as session:
        user = session.query(models.User).get(user_id)

        if user is None:
            raise HTTPException(status_code=400,
                                detail='Неправильный ID пользователя!')

        group = session.query(models.Group).get(group_id)

        if group is None:
            raise HTTPException(status_code=400,
                                detail='Неправильный ID группы!')

        user.groups.add(group)

        session.commit()

        return {'ok': True}


@App.post('/groups/remove_user_from_group',
          summary=['Удалить пользователя из группы'],
          tags=['Группы'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def remove_user_from_group(_request: Request,
                           user_id: Annotated[int, Body()],
                           group_id: Annotated[int, Body()]):
    with Session(models.engine) as session:
        user = session.query(models.User).get(user_id)

        if user is None:
            raise HTTPException(status_code=400,
                                detail='Неправильный ID пользователя!')

        group = session.query(models.Group).get(group_id)

        if group is None:
            raise HTTPException(status_code=400,
                                detail='Неправильный ID группы!')

        if group not in user.groups:
            raise HTTPException(status_code=400,
                                detail='Пользователя нет в этой группе!')

        user.groups.remove(group)

        session.commit()

        return {'ok': True}


@App.get('/groups/get_users_in_group',
         summary='Получить пользователей из группы',
         tags=['Группы'])
@privilege_level_required(minimal_level=models.UserType.Teacher)
def get_users_in_group(_request: Request,
                       group_id: int):
    with Session(models.engine) as session:
        group = session.query(models.Group).get(group_id)

        if group is None:
            raise HTTPException(status_code=400,
                                detail='Неправильный ID группы!')

        return [get_dict_from_user_model(user) for user in group.users]


@App.get('/groups/group',
         summary='Получить информацию о группе',
         tags=['Группы'])
@privilege_level_required(minimal_level=models.UserType.Teacher)
def get_group(_request: Request,
              group_id: int):
    with Session(models.engine) as session:
        group = session.query(models.Group).get(group_id)

        if group is None:
            raise HTTPException(status_code=404,
                                detail='Неправильный ID группы!')

        return {
            'id': group.id,
            'name': group.name,
            'users': [get_dict_from_user_model(user) for user in group.users]
        }