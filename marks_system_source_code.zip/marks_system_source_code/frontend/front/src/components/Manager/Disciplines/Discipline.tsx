import React, { useEffect, useState } from "react";
import { useAppDispatch } from "../../../store/hooks";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "antd";

interface DataType {
  id: number;
  name: string;
}

const Discipline = () => {
  
  const params = useParams<{ id: string }>();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const fetch = async () => {
    //dispatch(getDisciplines());
  };

  useEffect(() => {
    fetch();
  }, []);

  return (
    <div className="profile">
      <Button className="profile__top-btn" onClick={() => navigate(-1)}>
        К списку дисциплин
      </Button>
      <div className="profile__title _h3">Управление дисциплиной</div>
     

    </div>
  );
};

export default Discipline;
