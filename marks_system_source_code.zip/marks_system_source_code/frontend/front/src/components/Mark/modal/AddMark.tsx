import React, { useEffect } from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import { openErrorNotification, openSuccessNotification } from "../../../utils/Notification";
import { Button } from "antd";
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import { getUsers } from "../../../store/userReducer";
import SelectInput from "../../UI/Select";
import { groupsAPI, marksAPI } from "../../../api/api";
import { mark, requiredField } from "../../../utils/validators/validators";

type addUserGroup = {
  mark_type: string;
  percent: number;
};

const AddMark = ({ fetch, closeModal, group_id, user_id, discipline_id, category_id }: any) => {
  const users = useAppSelector((state) => state.users.listUsers);
  const dispatch = useAppDispatch();

  const usersForInput = users.map((e: any) => ({
    value: e.id,
    label: e.name,
  }));

  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors },
  } = useForm<addUserGroup>();

  const onSubmit: SubmitHandler<addUserGroup> = async (data) => {
    try {
      await marksAPI.addMark(user_id, group_id, discipline_id, category_id, data.mark_type, Number(data.percent));
      reset();
      await fetch();
      closeModal();
      openSuccessNotification("Успешное добавление оценки");
    } catch (e: any) {
      openErrorNotification("Ошибка добавления оценки");
    }
  };

  useEffect(() => {
    dispatch(getUsers());
  }, []);
  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div style={{ marginBottom: "10px" }}>Выберите тип оценки:</div>
      <SelectInput
        data={[
          { value: "Exam", label: "Экзамен" },
          { value: "Test", label: "Зачет" },
          { value: "TestWithMark", label: "Диф. зачет" },
        ]}
        name="mark_type"
        control={control}
        showSearch={true}
      />
      {errors.mark_type && <div className="input__error">{errors.mark_type.message}</div>}
      <div className="login__input-wrap input" style={{margin: '15px 0'}}>
        <label className="input__label" htmlFor="percent">
          Оценка* (если тип зачет, передавайте 0 - если не зачет и 100 - если зачет)
        </label>
        <input
          {...register("percent", mark)}
          className="input__input"
          type="text"
          placeholder="Оценка"
          id="percent"
        />
        {errors.percent && <div className="input__error">{errors.percent.message}</div>}
      </div>
      <div style={{ display: "flex", alignItems: "center", marginTop: "20px" }}>
        <Button htmlType="button" onClick={closeModal}>
          Отмена
        </Button>
        <Button htmlType="submit" style={{ marginLeft: "10px" }} type="primary">
          Добавить
        </Button>
      </div>
    </form>
  );
};

export default AddMark;
