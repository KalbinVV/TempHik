from typing import Annotated, Type

from sqlalchemy.orm import Session

import models
from app import App
from decorators.security_decorators import privilege_level_required

from fastapi import Request, Body, HTTPException


@App.post('/disciplines/discipline',
          summary='Добавить новую дисциплину',
          tags=['Дисциплины'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def add_new_discipline(_request: Request,
                       name: Annotated[str, Body()],
                       group_ids: Annotated[list[int], Body()]):
    with Session(models.engine) as session:
        discipline = models.Discipline(name=name)

        session.add(discipline)

        for group_id in group_ids:
            group: Type[models.Group] = session.query(models.Group).get(group_id)

            if group is None:
                raise HTTPException(status_code=400,
                                    detail=f'Неправильный ID группы: {group_id}')

            group.disciplines.add(discipline)

        session.commit()

        return {'discipline_id': discipline.id}


@App.put('/disciplines/discipline',
         summary='Обновить дисциплину',
         tags=['Дисциплины'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def update_discipline(_request: Request,
                      discipline_id: Annotated[int, Body()],
                      name: Annotated[str, Body()],
                      groups_ids: Annotated[list[int], Body()]):
    with Session(models.engine) as session:
        discipline = session.query(models.Discipline).get(discipline_id)

        if discipline is None:
            raise HTTPException(status_code=400,
                                detail='Неправильный ID дисциплины!')

        discipline.name = name

        discipline.groups.clear()

        for group_id in groups_ids:
            group: Type[models.Group] = session.query(models.Group).get(group_id)

            if group is None:
                raise HTTPException(status_code=400,
                                    detail=f'Неправильный ID группы: {group_id}')

            group.disciplines.add(discipline)

        session.commit()

        return {'ok': True}


@App.get('/disciplines/list',
         summary='Получить список дисциплин группы',
         tags=['Дисциплины'])
@privilege_level_required(minimal_level=models.UserType.Teacher)
def get_disciplines_list(_request: Request,
                         group_id: int):
    with Session(models.engine) as session:
        group = session.query(models.Group).get(group_id)

        if group is None:
            raise HTTPException(status_code=400,
                                detail='Неправильный ID группы!')

        return [{'id': discipline.id,
                 'name': discipline.name} for discipline in group.disciplines]


@App.put('/disciplines/bind_discipline',
         summary='Привязать дисциплину к группе',
         tags=['Дисциплины'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def bind_discipline_to_group(_request: Request,
                             discipline_id: Annotated[int, Body()],
                             group_id: Annotated[int, Body()]):
    with Session(models.engine) as session:
        discipline = session.query(models.Discipline).get(discipline_id)

        if discipline is None:
            raise HTTPException(status_code=400,
                                detail='Неправильный ID дисциплины!')

        group = session.query(models.Group).get(group_id)

        if group is None:
            raise HTTPException(status_code=400,
                                detail='Неправильный ID группы!')

        group.disciplines.add(discipline)

        return {'ok': True}


@App.put('/disciplines/unbind_discipline',
         summary='Отвязать дисциплину от группы',
         tags=['Дисциплины'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def bind_discipline_to_group(_request: Request,
                             discipline_id: Annotated[int, Body()],
                             group_id: Annotated[int, Body()]):
    with Session(models.engine) as session:
        discipline = session.query(models.Discipline).get(discipline_id)

        if discipline is None:
            raise HTTPException(status_code=400,
                                detail='Неправильный ID дисциплины!')

        group = session.query(models.Group).get(group_id)

        if group is None:
            raise HTTPException(status_code=400,
                                detail='Неправильный ID группы!')

        if discipline in group.disciplines:
            group.disciplines.remove(discipline)

        return {'ok': True}


@App.put('/disciplines/remove',
         summary='Удалить дисциплину',
         tags=['Дисциплины'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def remove_discipline(_request: Request,
                      discipline_id: Annotated[int, Body()]):
    with Session(models.engine) as session:
        session.query(models.Discipline).filter_by(id=discipline_id).delete()

        session.commit()

        return {'ok': True}


@App.get('/disciplines/all',
         summary='Получить список всех дисциплин',
         tags=['Дисциплины'])
@privilege_level_required(minimal_level=models.UserType.Teacher)
def get_all_disciplines(_request: Request):
    with Session(models.engine) as session:
        disciplines = session.query(models.Discipline).all()

        return [{'id': discipline.id,
                'name': discipline.name,
                'groups': [{'id': group.id,
                            'name': group.name} for group in discipline.groups]} for discipline in disciplines]


@App.get('/disciplines/discipline',
         summary='Получить информацию о дисциплине',
         tags=['Дисциплины'])
@privilege_level_required(minimal_level=models.UserType.Teacher)
def get_discipline(_request: Request, discipline_id: int):
    with Session(models.engine) as session:
        discipline = session.query(models.Discipline).get(discipline_id)

        if discipline is None:
            raise HTTPException(status_code=400,
                                detail='Неправильный ID дисциплины!')

        return {
            'id': discipline.id,
            'name': discipline.name,
            'groups': [{'id': group.id,
                        'name': group.name} for group in discipline.groups]
        }