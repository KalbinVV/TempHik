import React, { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { Button, Modal, Table, TableColumnsType } from "antd";
import { CheckOutlined, DeleteOutlined, PlusOutlined } from "@ant-design/icons";
import { getGroupOnlyStudents, getGroups } from "../../store/groupReducer";
import { getGroupDisciplines } from "../../store/disciplinesReducer";
import { getCat } from "../../store/catReducer";
import { openErrorNotification, openSuccessNotification } from "../../utils/Notification";
import { marksAPI } from "../../api/api";
import { getUserMark, removeMarks } from "../../store/marksReducer";
import AddMark from "./modal/AddMark";
import { loadingStatus } from "../../store/appReducer";

type Inputs = {
  login: string;
  password: string;
  fullname: string;
  user_type: number;
  groups_ids: Array<number>;
};

interface GroupsType {
  id: number;
  name: string;
}

const MarksManager = () => {
  const [isModalDelOpen, setIsModalDelOpen] = useState<boolean>(false);
  const typeUser = useAppSelector((state) => state.auth.userType);
  const myGroups = useAppSelector((state) => state.groups.myGroups);
  const usersGroup = useAppSelector((state) => state.groups.usersGroup);
  const allGroups = useAppSelector((state) => state.groups.listGroup);
  const catGroup = useAppSelector((state) => state.cat.listCat);
  const userMark = useAppSelector((state) => state.marks.listMarks);
  const disciplinesState = useAppSelector((state) => state.disciplines.listDisciplines);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [currentGroup, setCurrentGroup] = useState<null | { id: number; name: string }>(null);
  const [currentDiscipline, setCurrentDisciplinep] = useState<null | { id: number; name: string }>(null);
  const [currentCat, setCurrentCat] = useState<null | { id: number; name: string }>(null);
  const [currentUser, setCurrentUser] = useState<null | { id: number; name: string }>(null);
  const [currentMark, setCurrentMark] = useState<any>(undefined);

  const dispatch = useAppDispatch();

  const onAddGroup = (id: number, name: string) => {
    setCurrentGroup({ id, name });
  };

  const onAddDiscipline = (id: number, name: string) => {
    setCurrentDisciplinep({ id, name });
  };

  const onAddCat = (id: number, name: string) => {
    setCurrentCat({ id, name });
  };

  const onAddUser = (id: number, name: string) => {
    setCurrentUser({ id, name });
    if (currentGroup) {
      dispatch(getUserMark(id, currentGroup?.id));
    }
  };

  const onFetch = () => {
    if (currentGroup && currentUser) {
      dispatch(getUserMark(currentUser.id, currentGroup?.id));
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setIsModalDelOpen(false);
  };

  const columnsGroup: TableColumnsType<GroupsType> = [
    {
      title: "Название группы",
      key: "name",
      dataIndex: "name",
    },
    {
      title: "Выбрать",
      dataIndex: "",
      width: "90px",
      render: (a) => (
        <div className="table__inner" style={{ justifyContent: "center" }}>
          <Button onClick={() => onAddGroup(a.id, a.name)} className="table__btn _green">
            <CheckOutlined />
          </Button>
        </div>
      ),
    },
  ];
  const disciplines: TableColumnsType<GroupsType> = [
    {
      title: "Название Дисциплины",
      key: "name",
      dataIndex: "name",
    },
    {
      title: "Выбрать",
      dataIndex: "",
      width: "90px",
      render: (a) => (
        <div className="table__inner" style={{ justifyContent: "center" }}>
          <Button onClick={() => onAddDiscipline(a.id, a.name)} className="table__btn _green">
            <CheckOutlined />
          </Button>
        </div>
      ),
    },
  ];
  const cats: TableColumnsType<GroupsType> = [
    {
      title: "Название семестра",
      key: "name",
      dataIndex: "name",
    },
    {
      title: "Выбрать",
      dataIndex: "",
      width: "90px",
      render: (a) => (
        <div className="table__inner" style={{ justifyContent: "center" }}>
          <Button onClick={() => onAddCat(a.id, a.name)} className="table__btn _green">
            <CheckOutlined />
          </Button>
        </div>
      ),
    },
  ];
  const users: TableColumnsType<GroupsType> = [
    {
      title: "ФИО",
      key: "name",
      dataIndex: "name",
    },
    {
      title: "Выбрать",
      dataIndex: "",
      width: "90px",
      render: (a) => (
        <div className="table__inner" style={{ justifyContent: "center" }}>
          <Button onClick={() => onAddUser(a.id, a.name)} className="table__btn _green">
            <CheckOutlined />
          </Button>
        </div>
      ),
    },
  ];

  useEffect(() => {
    dispatch(getGroups());
    dispatch(getCat());
    dispatch(getGroupDisciplines());
  }, []);

  useEffect(() => {
    if (currentGroup) {
      dispatch(getGroupDisciplines(currentGroup.id));
      dispatch(getGroupOnlyStudents(currentGroup.id));
    }
  }, [currentGroup]);

  useEffect(() => {
    if (currentDiscipline && currentGroup) {
      dispatch(getCat(currentGroup.id));
    }
  }, [currentDiscipline]);

  const reset = () => {
    setCurrentGroup(null);
    setCurrentDisciplinep(null);
    setCurrentCat(null);
    setCurrentUser(null);
    dispatch(getCat());
    dispatch(getGroupDisciplines());
    dispatch(removeMarks());
  };

  const removeMark = async () => {
    dispatch(loadingStatus(true));
    try {
      const { data } = await marksAPI.removeMark(currentMark.id);
      openSuccessNotification("Успешное удаление оценки");
    } catch (e) {
      openErrorNotification("Ошибка удаления оценки");
    }
    setIsModalDelOpen(false);
    onFetch();
    dispatch(loadingStatus(false));
  };

  useEffect(() => {
    if (userMark.length) {
      let currentMark = null;
      const currentMarkCat = userMark.filter((e: any) => e.id === currentCat?.id)[0];
      if (currentMarkCat) {
        currentMark = currentMarkCat.marks.filter((e: any) => e.discipline.id === currentDiscipline?.id)[0];
      }

      if (currentMark) {
        setCurrentMark(currentMark);
      } else {
        setCurrentMark(null);
      }
    }
  }, [userMark]);

  return (
    <section className="marks">
      <div className="profile__title _h3">Управление оценками</div>
      <div className="marks__text">Выберите группу, дисциплину, семестр и студента</div>
      {currentGroup && (
        <Button onClick={reset} style={{ marginBottom: "20px" }} danger>
          Сбросить выбор
        </Button>
      )}
      {currentGroup ? (
        <div>Текущая группа: {currentGroup.name}</div>
      ) : (
        <Table
          className="profile__table"
          dataSource={typeUser === 2 ? allGroups : myGroups}
          columns={columnsGroup}
          pagination={false}
        />
      )}
      {currentDiscipline && `Дисциплина: ${currentDiscipline.name}`}
      {currentCat && <div>{`Категория: ${currentCat.name}`}</div>}
      {currentUser && <div>{`Студент: ${currentUser.name}`}</div>}
      {disciplinesState.length && !currentDiscipline ? (
        <Table className="profile__table" dataSource={disciplinesState} columns={disciplines} pagination={false} />
      ) : (
        ""
      )}
      {catGroup.length && !currentCat ? (
        <Table className="profile__table" dataSource={catGroup} columns={cats} pagination={false} />
      ) : (
        ""
      )}
      {currentCat && !currentUser && (
        <>
          <Table className="profile__table" dataSource={usersGroup} columns={users} pagination={false} />
        </>
      )}
      {currentMark !== undefined && currentUser && (
        <div className="marks__info-inner-wrap">
          <div className="marks__info">
            <div className={`marks__info-top ${typeUser === 1 ? '_2': ''}`}>
              <div className="marks__info-title">Ученик</div>
              <div className="marks__info-title">Текущая оценка</div>
              <div className="marks__info-title">Тип оценки</div>
              {typeUser === 2 && <div className="marks__info-title">Действия</div>}
            </div>
            <div className={`marks__info-inner ${typeUser === 1 ? '_2': ''}`}>
              <div className="marks__info-text">{currentUser.name}</div>
              <div className="marks__info-text">
                {currentMark?.percent !== null ? (
                  currentMark?.type === "Test" ? (
                    <>{currentMark?.percent > 3 ? "Зачет" : "Не зачет"}</>
                  ) : (
                    currentMark?.percent
                  )
                ) : (
                  "нет оценки"
                )}
              </div>
              <div className="marks__info-text">
                {currentMark?.type ? (
                  <>
                    {" "}
                    {currentMark.type === "Exam" && "Экзамен"}
                    {currentMark.type === "Test" && "Зачет"}
                    {currentMark.type === "TestWithMark" && "Диф. зачет"}
                  </>
                ) : (
                  "Нет оценки"
                )}
              </div>
              {typeUser === 2 && (
                <div className="marks__info-inner-btn">
                  {currentMark?.percent !== null ? (
                    <Button
                      onClick={() => setIsModalDelOpen(true)}
                      danger
                      type="primary"
                      icon={<DeleteOutlined />}
                    ></Button>
                  ) : (
                    ""
                  )}

                  <Button
                    danger
                    type="primary"
                    onClick={() => setIsModalOpen(true)}
                    style={{ backgroundColor: "green" }}
                    icon={<PlusOutlined />}
                  ></Button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
      <Modal
        title="Добавление/изменение оценки"
        open={isModalOpen}
        footer={null}
        onOk={closeModal}
        onCancel={closeModal}
      >
        <AddMark
          fetch={onFetch}
          closeModal={closeModal}
          category_id={currentCat?.id}
          group_id={currentGroup?.id}
          user_id={currentUser?.id}
          discipline_id={currentDiscipline?.id}
        />
      </Modal>
      <Modal
        title="Удалить оценку"
        open={isModalDelOpen}
        onOk={removeMark}
        onCancel={closeModal}
        okType="danger"
        okText="Удалить"
        cancelText="Закрыть"
      >
        Хотите удалить текущую оценку?
      </Modal>
    </section>
  );
};

export default MarksManager;
