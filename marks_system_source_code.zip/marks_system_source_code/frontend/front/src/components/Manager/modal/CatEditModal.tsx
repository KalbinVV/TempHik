import React from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import { requiredField } from "../../../utils/validators/validators";
import { Button } from "antd";
import { catAPI } from "../../../api/api";
import { openErrorNotification, openSuccessNotification } from "../../../utils/Notification";

type addGroup = {
  name: string;
};

const CatEditModal = ({ fetch, closeModal, currentGroup }: any) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<addGroup>();

  const onSubmit: SubmitHandler<addGroup> = async (data) => {
    try {
      console.log(data);
      await catAPI.editCat(currentGroup.id, data.name);
      reset();
      await fetch();
      closeModal();
      openSuccessNotification("Успешное изменение семестра");
    } catch (e: any) {
      openErrorNotification("Ошибка изменение семестра");
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div style={{ marginBottom: "10px" }}>Вы изменяете название семестра {currentGroup.name}</div>
      <div style={{ marginBottom: "10px" }}>Введите новое название семестра:</div>
      <input
        className="input__input "
        type="text"
        placeholder="Название семестра"
        {...register("name", requiredField)}
      />
      {errors.name && <div className="input__error">{errors.name.message}</div>}
      <div style={{ display: "flex", alignItems: "center", marginTop: "20px" }}>
        <Button htmlType="button" onClick={closeModal}>
          Отмена
        </Button>
        <Button htmlType="submit" style={{ marginLeft: "10px" }} type="primary">
          Изменить
        </Button>
      </div>
    </form>
  );
};

export default CatEditModal;
