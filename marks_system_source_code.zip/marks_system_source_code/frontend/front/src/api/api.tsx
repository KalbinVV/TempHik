import { idText } from "typescript";
import { instance } from "./axios";

export const authAPI = {
  me() {
    return instance.get(`auth/me`);
  },

  login(login: string, password: string) {
    return instance.post("auth/login", {
      login,
      password,
    });
  },

  logOut() {
    return instance.post(`auth/logout`);
  },

  register({
    login,
    password,
    fullname,
    user_type,
    groups_ids,
  }: {
    login: string;
    password: string;
    fullname: string;
    user_type: number;
    groups_ids: Array<number>;
  }) {
    return instance.post("auth/register", {
      login,
      password,
      fullname,
      user_type,
      groups_ids,
    });
  },

  update(
    {
      login,
      password,
      fullname,
      user_type,
      groups_ids,
    }: {
      login: string;
      password: string;
      fullname: string;
      user_type: number;
      groups_ids: Array<number>;
    },
    id: number
  ) {
    return instance.post("auth/update_user", {
      user_id: id,
      login,
      password,
      fullname,
      user_type,
      groups_ids,
    });
  },
};

export const groupsAPI = {
  getList() {
    return instance.get(`groups/list`);
  },
  getGroup(id: number) {
    return instance.get(`groups/group?group_id=${id}`);
  },
  addUserGroup(userId: number, groupId: number) {
    return instance.post(`groups/user_groups`, {
      user_id: userId,
      group_id: groupId,
    });
  },
  getGroupStudents(id: number) {
    return instance.get(`groups/get_users_in_group?group_id=${id}`);
  },
  addGroup(name: string) {
    return instance.post(`groups/group?name=${name}`);
  },
  removeGroup(id: number) {
    return instance.put(`groups/delete`, id);
  },
  editGroup(id: number, name: string) {
    return instance.put(`groups/group`, { group_id: id, name });
  },
  removeUserGroup(user_id: number, group_id: number) {
    return instance.post(`groups/remove_user_from_group`, {
      user_id,
      group_id,
    });
  },
};

export const usersAPI = {
  getUsers() {
    return instance.get(`auth/users`);
  },
  deleteUsers(id: number) {
    return instance.put(`users/remove_user`, id);
  },
  getUser(id: number) {
    return instance.get(`auth/user?user_id=${id}`);
  },
};

export const disciplinesAPI = {
  getGroupDisciplines(id: number) {
    return instance.get(`disciplines/list?group_id=${id}`);
  },
  getDisciplines() {
    return instance.get(`disciplines/all`);
  },

  addDiscipline(name: string, group_ids: Array<number>) {
    return instance.post(`disciplines/discipline`, {
      name: name,
      group_ids: group_ids,
    });
  },
  removeDiscipline(id: number) {
    return instance.put(`disciplines/remove`, id);
  },
  editDiscipline(id: number, name: string, groups_ids: Array<any>) {
    return instance.put(`disciplines/discipline`, { discipline_id: id, name, groups_ids });
  },
};

export const catAPI = {
  getCat(id: number) {
    return instance.get(`categories/group_list?group_id=${id}`);
  },
  addCat(id: number, name: string) {
    return instance.post(`categories/category`, {
      group_id: id,
      name: name,
    });
  },
  removeCat(id: number) {
    return instance.put(`categories/remove_category?category_id=${id}`);
  },
  editCat(id: number, name: string) {
    return instance.put(`categories/category`, {
      category_id: id,
      name,
    });
  },
};

export const marksAPI = {
  getUserMark(user_id: number, group_id: number) {
    return instance.get(`marks/user_marks?user_id=${user_id}&group_id=${group_id}`);
  },
  getMyMark(group_id: number) {
    return instance.get(`marks/my_marks?group_id=${group_id}`);
  },
  removeMark(id: number) {
    return instance.put(`marks/remove_mark`, id);
  },
  addMark(
    user_id: number,
    group_id: number,
    discipline_id: number,
    category_id: number,
    mark_type: string,
    percent: number
  ) {
    return instance.post(`marks/mark`, {
      user_id,
      group_id,
      discipline_id,
      category_id,
      mark_type,
      percent,
    });
  },
};
