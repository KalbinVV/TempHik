import { Button } from "antd";
import React from "react";
import { MAIN_PATH, REGISTRATION_PATH } from "../../utils/const";
import { Link, Navigate } from "react-router-dom";
import { SubmitHandler, useForm } from "react-hook-form";
import { requiredField } from "../../utils/validators/validators";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { login } from "../../store/authReducer";

type Inputs = {
  name: string;
  password: string;
};

function Login() {

  const isAuth = useAppSelector((state) => state.auth.isAuth);

  const dispatch = useAppDispatch();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<Inputs>();

  const onSubmit: SubmitHandler<Inputs> = (data) => {
    dispatch(login(data.name, data.password))
  };

  
  if (isAuth) {
    return <Navigate to={MAIN_PATH} replace={true} />;
  }

  return (
    <section className="login">
      <div className="container">
        <form className="login__wrap">
          <div className="login__title _h3">Авторизация</div>
          <div className="login__inner">
            <div className="login__input-wrap input">
              <label className="input__label" htmlFor="name">
                Имя*
              </label>
              <input
                {...register("name", requiredField)}
                className="input__input"
                type="text"
                placeholder="Ваше имя"
                id="name"
              />
              {errors.name && <div className="input__error">{errors.name.message}</div>}
            </div>
            <div className="login__input-wrap input">
              <label className="input__label" htmlFor="pass">
                Пароль*
              </label>
              <input
                {...register("password", requiredField)}
                className="input__input"
                type="password"
                placeholder="Ваш пароль"
                id="pass"
              />
              {errors.password && <div className="input__error">{errors.password.message}</div>}
            </div>
          </div>
          <Button className="login__btn" type="primary" onClick={handleSubmit(onSubmit)}>
            Авторизоваться
          </Button>
         
        </form>
      </div>
    </section>
  );
}
export default Login;
