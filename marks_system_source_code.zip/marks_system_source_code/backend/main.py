import importlib

from app import App
from models import init_tables

importlib.import_module('api.auth')
importlib.import_module('api.groups')
importlib.import_module('api.marks')
importlib.import_module('api.categories')
importlib.import_module('api.disciplines')


app = App


@App.on_event('startup')
def on_startup():
    init_tables()

