import React from "react";
import { Link } from "react-router-dom";
import { DISCIPLINES_PATH, GROUP_PATH,  USERS_PATH } from "../../utils/const";

const Manager = () => {

  return (
    <div className="profile">
      <div className="profile__title _h3">Управление</div>
      <ul className="profile__manager-list">
        <li className="profile__manager-item">
          <Link className="profile__manager-link" to={GROUP_PATH}>
            Управления группами
          </Link>
        </li>
        <li className="profile__manager-item">
          <Link className="profile__manager-link" to={USERS_PATH}>
            Управления пользователями 
          </Link>
        </li>
        <li className="profile__manager-item">
          <Link className="profile__manager-link" to={DISCIPLINES_PATH}>
            Управления дисциплинами 
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default Manager;
