import { createSlice, PayloadAction } from "@reduxjs/toolkit";

import { loadingStatus } from "./appReducer";
import { disciplinesAPI, groupsAPI } from "../api/api";

export interface InitialStateType {
  listDisciplines: Array<{ key: number; id: number; name: string; groups: Array<{ id: number; name: string }> }>;
  //disciplinesName: string | null;
  // groupId: number | null;
  //usersGroup: Array<any>;
}

const initialState: InitialStateType = {
  listDisciplines: [],
  // groupName: null,
  // groupId: null,
  //usersGroup: [],
};

export const disciplinesReducer = createSlice({
  name: "disciplines",
  initialState,
  reducers: {
    setDisciplines: (
      state,
      action: PayloadAction<
        Array<{ key: number; id: number; name: string; groups: Array<{ id: number; name: string }> }>
      >
    ) => {
      state.listDisciplines = action.payload;
    },
  },
});

export const { setDisciplines } = disciplinesReducer.actions;

export const getDisciplines = () => async (dispatch: any) => {
  dispatch(loadingStatus(true));

  try {
    const { data } = await disciplinesAPI.getDisciplines();

    dispatch(
      setDisciplines(
        data.map((e: any) => ({
          key: e.id,
          id: e.id,
          name: e.name,
          groups: e.groups,
        }))
      )
    );
  } catch (err: any) {
    console.error(err);
  }

  dispatch(loadingStatus(false));
};

export const getGroupDisciplines = (id?:number) => async (dispatch: any) => {
  dispatch(loadingStatus(true));

  try {
    if (id){
      const { data } = await disciplinesAPI.getGroupDisciplines(id);
      dispatch(
        setDisciplines(
          data.map((e: any) => ({
            key: e.id,
            id: e.id,
            name: e.name
          }))
        )
      );
    } else {
      dispatch(
        setDisciplines([])
      );
    }
   
  } catch (err: any) {
    console.error(err);
  }

  dispatch(loadingStatus(false));
};


export default disciplinesReducer.reducer;
