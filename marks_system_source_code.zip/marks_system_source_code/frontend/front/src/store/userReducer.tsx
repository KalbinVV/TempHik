import { createSlice, PayloadAction } from "@reduxjs/toolkit";

import { loadingStatus } from "./appReducer";
import { usersAPI } from "../api/api";

type ListUsers = Array<{ key: number; id: number; name: string; userType: number; groups: Array<any>; login: string }>;

type userType = {
  user_id: number;
  login: string;
  user_type: number;
  fullname: string;
  groups: Array<any>;
};

export interface InitialStateType {
  listUsers: ListUsers;
  user: userType | null;
}

const initialState: InitialStateType = {
  listUsers: [],
  user: null,
};

export const userReducer = createSlice({
  name: "user",
  initialState,
  reducers: {
    setUsers: (state, action: PayloadAction<ListUsers>) => {
      state.listUsers = action.payload;
    },
    setUser: (state, action: PayloadAction<userType | null>) => {
      state.user = action.payload;
    },
  },
});

export const { setUsers, setUser } = userReducer.actions;

export const getUsers = () => async (dispatch: any) => {
  dispatch(loadingStatus(true));

  try {
    const { data } = await usersAPI.getUsers();

    dispatch(
      setUsers(
        data.map((e: any) => ({
          key: e.user_id,
          id: e.user_id,
          name: e.fullname,
          userType: e.user_type,
          groups: e.groups,
          login: e.login,
        }))
      )
    );
  } catch (err: any) {
    console.error(err);
  }

  dispatch(loadingStatus(false));
};

export const getUser = (id?: number) => async (dispatch: any) => {
  dispatch(loadingStatus(true));

  try {
    if (id) {
      const { data } = await usersAPI.getUser(id);

      dispatch(
        setUser({
          user_id: data.user_id,
          login: data.login,
          user_type: data.user_type,
          fullname: data.fullname,
          groups: data.groups,
        })
      );
    } else {
      dispatch(setUser(null));
    }
  } catch (err: any) {
    console.error(err);
  }

  dispatch(loadingStatus(false));
};

export const deleteUserThunk = (id: number) => async (dispatch: any) => {
  dispatch(loadingStatus(true));

  try {
    const { data } = await usersAPI.deleteUsers(id);

    dispatch(setUser(null));
  } catch (err: any) {
    console.error(err);
  }

  dispatch(loadingStatus(false));
};

export default userReducer.reducer;
