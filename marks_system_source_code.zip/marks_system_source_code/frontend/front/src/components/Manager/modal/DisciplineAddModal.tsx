import React, { useEffect } from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import { requiredField } from "../../../utils/validators/validators";
import { Button } from "antd";
import { disciplinesAPI, } from "../../../api/api";
import { openErrorNotification, openSuccessNotification } from "../../../utils/Notification";
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import { getGroups } from "../../../store/groupReducer";
import SelectInputMulti from "../../UI/SelectMulti";

type addGroup = {
  name: string;
  group_ids: Array<number>;
};

const DisciplineAddModal = ({ fetch, closeModal }: any) => {
  const groups = useAppSelector((state) => state.groups.listGroup);

  const dispatch = useAppDispatch();

  const groupsForInput = groups.map((e: { id: number; name: string }) => ({
    value: e.id,
    label: e.name,
  }));

  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors },
  } = useForm<addGroup>();

  const onSubmit: SubmitHandler<addGroup> = async (data) => {
    try {
      console.log(data);
      await disciplinesAPI.addDiscipline(data.name, data.group_ids);
      reset();
      await fetch();
      closeModal();
      openSuccessNotification("Успешное добавление дисциплины");
    } catch (e: any) {
      openErrorNotification("Ошибка добавления дисциплины");
    }
  };

  useEffect(() => {
    dispatch(getGroups());
  }, []);

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="login__input-wrap input" style={{marginBottom: '10px'}}>
        <label className="input__label" htmlFor="name">
          Введите название дисциплины:*
        </label>
        <input
          className="input__input "
          type="text"
          id="name"
          placeholder="Название дисциплины"
          {...register("name", requiredField)}
        />
        {errors.name && <div className="input__error">{errors.name.message}</div>}
      </div>
      <div className="login__input-wrap input">
        <label className="input__label" htmlFor="groups_ids">
          Группы*
        </label>

        <SelectInputMulti data={groupsForInput} name="group_ids" control={control} />

        {errors.group_ids && <div className="input__error">{errors.group_ids.message}</div>}
      </div>
      <div style={{ display: "flex", alignItems: "center", marginTop: "20px" }}>
        <Button htmlType="button" onClick={closeModal}>
          Отмена
        </Button>
        <Button htmlType="submit" style={{ marginLeft: "10px" }} type="primary">
          Добавить
        </Button>
      </div>
    </form>
  );
};

export default DisciplineAddModal;
