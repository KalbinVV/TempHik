import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import { Provider } from "react-redux";
import MainApp from "./MainApp";
import { store } from "./store/store";
import { ConfigProvider } from "antd";

const root = ReactDOM.createRoot(document.getElementById("root") as HTMLElement);
root.render(
  <Provider store={store}>
    <ConfigProvider theme={{
      token: {
      
        colorPrimary: '#2F80ED',
      },
    }}>
      <MainApp />
    </ConfigProvider>
  </Provider>
);
