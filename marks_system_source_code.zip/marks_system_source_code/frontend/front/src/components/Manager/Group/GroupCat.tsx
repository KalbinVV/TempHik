import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import { getGroup } from "../../../store/groupReducer";
import { Button, Modal, Table, TableColumnsType } from "antd";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { openErrorNotification, openSuccessNotification } from "../../../utils/Notification";
import { catAPI } from "../../../api/api";
import { getCat } from "../../../store/catReducer";
import CatAddModal from "../modal/CatAddModal";
import CatEditModal from "../modal/CatEditModal";

interface DataType {
  id: number;
  name: string;
}

const GroupCat = () => {
  const catList = useAppSelector((state) => state.cat.listCat);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [isModalDelOpen, setIsModalDelOpen] = useState<boolean>(false);
  const [isModalEditOpen, setIsModalEditOpen] = useState<boolean>(false);
  const [currentCat, setCurrentCat] = useState<{ id: number; name: string } | null>(null);
  const groupName = useAppSelector((state) => state.groups.groupName);

  const params = useParams<{ id: string }>();

  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const columns: TableColumnsType<DataType> = [
    {
      title: "Имя",
      key: "name",
      dataIndex: "name",
    },

    {
      title: "Управление",
      width: "102px",
      render: (a) => (
        <div className="table__inner" style={{ justifyContent: "center" }}>
          <Button
            onClick={() => {
              setIsModalDelOpen(true);
              setCurrentCat({ id: a.id, name: a.name });
            }}
            className="table__btn _del"
            danger
          >
            <DeleteOutlined />
          </Button>
          <Button
            onClick={() => {
              setIsModalEditOpen(true);
              setCurrentCat({ id: a.id, name: a.name });
            }}
            className="table__btn _edit"
          >
            <EditOutlined />
          </Button>
        </div>
      ),
    },
  ];

  const removeCat = async () => {
    try {
      if (currentCat) {
        const { data } = await catAPI.removeCat(currentCat.id);
        openSuccessNotification("Успешное удаление");
        onFetch();
      }
    } catch (e) {
      console.error(e);
      openErrorNotification("Ошибка при удаление");
    }
    setIsModalDelOpen(false);
    setCurrentCat(null);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setIsModalDelOpen(false);
    setIsModalEditOpen(false);
  };

  const onFetch = () => {
    dispatch(getGroup(Number(params.id)));
    dispatch(getCat(Number(params.id)));
  };

  useEffect(() => {
    onFetch();
  }, []);

  return (
    <div className="profile">
      <Button className="profile__top-btn" onClick={() => navigate(-1)}>
        К управлению группой
      </Button>
      <div className="profile__title _h3">Управление семестрами группы {groupName} </div>
      <Button type="primary" onClick={() => setIsModalOpen(true)}>
        Добавить семестр
      </Button>

      <Table
        title={() => <div className="_h4">Список семетров группы {groupName}</div>}
        className="profile__table"
        dataSource={catList}
        columns={columns}
        pagination={false}
      />

      <Modal title="Добавление семестра" open={isModalOpen} footer={null} onOk={closeModal} onCancel={closeModal}>
        <CatAddModal fetch={onFetch} closeModal={closeModal} id={Number(params.id)} />
      </Modal>

      <Modal
        title="Удалить семетрс"
        open={isModalDelOpen}
        onOk={removeCat}
        onCancel={closeModal}
        okType="danger"
        okText="Удалить"
        cancelText="Закрыть"
      >
        Хотите открепить от группы {currentCat?.name}?
      </Modal>
      <Modal
        title="Редактирование семестра"
        open={isModalEditOpen}
        footer={null}
        onOk={closeModal}
        onCancel={closeModal}
      >
        <CatEditModal fetch={onFetch} currentGroup={currentCat} closeModal={closeModal} />
      </Modal>
    </div>
  );
};

export default GroupCat;
