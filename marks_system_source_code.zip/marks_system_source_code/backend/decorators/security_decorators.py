from functools import wraps

import models

from fastapi import Request, Response

from utils import auth_utils


def privilege_level_required(minimal_level: models.UserType):
    def wrapper(func):
        @wraps(func)
        def _wrapper(*args, **kwargs):
            if 'request' in kwargs:
                request: Request = kwargs['request']
            elif '_request' in kwargs:
                request: Request = kwargs['_request']
            else:
                raise Exception(f'Not request for decorator for func: {func}')

            user = auth_utils.get_user_by_request(request)

            if user is None:
                return Response(status_code=403)

            if user.user_type.value < minimal_level.value:
                return Response(status_code=403)

            return func(*args, **kwargs)

        return _wrapper

    return wrapper
