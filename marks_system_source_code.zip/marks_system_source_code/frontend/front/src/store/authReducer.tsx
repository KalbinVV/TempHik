import { createSlice, PayloadAction } from "@reduxjs/toolkit";

import { loadingStatus } from "./appReducer";
import { authAPI } from "../api/api";
import { openErrorNotification } from "../utils/Notification";

export interface InitialStateType {
  isAuth: boolean;
  login: string | null;
  userId: number | null;
  error: string | null;
  userType: number | null;
  fullName: string | null;
}

const initialState: InitialStateType = {
  isAuth: false,
  login: null,
  userId: null,
  error: null,
  userType: null,
  fullName: null,
};

export const authReducer = createSlice({
  name: "auth",
  initialState,
  reducers: {
    setAuth: (state, action: PayloadAction<boolean>) => {
      state.isAuth = action.payload;
      if (!action.payload) {
        state.userId = null;
        state.userType = null;
        state.fullName = null;
      }
    },
    setAuthData: (state, action: PayloadAction<{ userId: number; userType: number; fullName: string }>) => {
      state.userId = action.payload.userId;
      state.userType = action.payload.userType;
      state.fullName = action.payload.fullName;
    },
  },
});

export const { setAuth, setAuthData } = authReducer.actions;

export const login = (login: string, password: string) => async (dispatch: any) => {
  dispatch(loadingStatus(true));

  try {
    const { data } = await authAPI.login(login, password);
    dispatch(setAuthData({ userId: data.user_id, userType: data.user_type, fullName: data.fullname }));
    dispatch(setAuth(true));
  } catch (err: any) {
    if (err.response && err.response.data) {
      openErrorNotification(err.response.data.detail);
    } else {
      console.error(err);
    }
  }

  dispatch(loadingStatus(false));
};

export const logOut = () => async (dispatch: any) => {
  dispatch(loadingStatus(true));

  try {
    const { data } = await authAPI.logOut();
    dispatch(setAuth(false));
  } catch (err: any) {
    if (err.message === "Network Error") {
      // dispatch(setError({ error: "Network Error" }));
    } else {
      const error = err.response.data.message;
      //dispatch(setError({ error }));
    }
  }

  dispatch(loadingStatus(false));
};

export default authReducer.reducer;
