import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { authAPI } from "../api/api";
import { setAuth, setAuthData } from "./authReducer";
import { setMyGroups } from "./groupReducer";

export interface InitialStateType {
  loading: boolean;
  typeApp: string;
  init: boolean;
  showMenu: boolean
}

const initialState: InitialStateType = {
  loading: true,
  typeApp: "",
  init: false,
  showMenu: false
};

export const appReducer = createSlice({
  name: "app",
  initialState,
  reducers: {
    loadingStatus: (state, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
    setTypeApp: (state, action: PayloadAction<string>) => {
      state.typeApp = action.payload;
    },

    setInit: (state, action: PayloadAction<boolean>) => {
      state.init = action.payload;
    },
    setIsShowMenu:(state, action: PayloadAction<boolean>) => {
      state.showMenu = action.payload;
    },
  },
});

export const { loadingStatus, setTypeApp, setInit, setIsShowMenu } = appReducer.actions;

export const initializeApp = () => async (dispatch: any) => {
  dispatch(loadingStatus(true));

  try {
    const { data } = await authAPI.me();
    dispatch(setAuthData({ userId: data.user_id, userType: data.user_type, fullName: data.fullname }));
    dispatch(setAuth(true));
    dispatch(setMyGroups(
      data.groups.map((e: any) => ({
        key: e.id,
        id: e.id,
        name: e.name,
      }))
    ))
  } catch (err: any) {
    if (err.message === "Network Error") {
      console.error("Network Error");
    } else {
      const error = err.response.data.message;
      if (err.response.status === 403) {
        console.warn("не авторизирован");
      }
    }
  }

  dispatch(setInit(true));
  dispatch(loadingStatus(false));
};

export default appReducer.reducer;
