import React from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import { requiredField } from "../../../utils/validators/validators";
import { Button } from "antd";
import { groupsAPI } from "../../../api/api";
import { openErrorNotification, openSuccessNotification } from "../../../utils/Notification";

type addGroup = {
  name: string;
};

const GroupAddModal = ({ fetch, closeModal }: any) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<addGroup>();

  const onSubmit: SubmitHandler<addGroup> = async (data) => {
    try {
      console.log(data);
      await groupsAPI.addGroup(data.name);
      reset();
      await fetch();
      closeModal();
      openSuccessNotification("Успешное добавление группы");
    } catch (e: any) {
      openErrorNotification("Ошибка добавления группы");
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div style={{ marginBottom: "10px" }}>Введите название группы:</div>
      <input className="input__input " type="text" placeholder="Название группы" {...register("name", requiredField)} />
      {errors.name && <div className="input__error">{errors.name.message}</div>}
      <div style={{ display: "flex", alignItems: "center", marginTop: "20px" }}>
        <Button htmlType="button" onClick={closeModal}>
          Отмена
        </Button>
        <Button htmlType="submit" style={{ marginLeft: "10px" }} type="primary">
          Добавить
        </Button>
      </div>
    </form>
  );
};

export default GroupAddModal;
