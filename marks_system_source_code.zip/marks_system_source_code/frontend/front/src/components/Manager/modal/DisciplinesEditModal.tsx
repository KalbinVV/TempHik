import React, { useEffect } from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import { requiredField } from "../../../utils/validators/validators";
import { Button } from "antd";
import { disciplinesAPI } from "../../../api/api";
import { openErrorNotification, openSuccessNotification } from "../../../utils/Notification";
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import { getGroups } from "../../../store/groupReducer";
import SelectInputMulti from "../../UI/SelectMulti";

type addGroup = {
  name: string;
  group_ids: Array<number>;
};

const DisciplinesEditModal = ({ fetch, closeModal, currentDisciplines, defaultValue }: any) => {
  const groups = useAppSelector((state) => state.groups.listGroup);
  console.log(currentDisciplines);
  const dispatch = useAppDispatch();

  const groupsForInput = groups.map((e: { id: number; name: string }) => ({
    value: e.id,
    label: e.name,
  }));

  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors },
  } = useForm<addGroup>({
    defaultValues: { name: currentDisciplines.name, group_ids: defaultValue.map((e: any) => e.id) },
  });

  const onSubmit: SubmitHandler<addGroup> = async (data) => {
    try {
      await disciplinesAPI.editDiscipline(currentDisciplines.id, data.name, data.group_ids);
      reset();
      await fetch();
      openSuccessNotification("Успешное изменение дисциплины");
    } catch (e: any) {
      openErrorNotification("Ошибка изменение дисциплины");
    }
    closeModal();
  };

  useEffect(() => {
    dispatch(getGroups());
  }, []);

  useEffect(() => {
    reset({
      name: currentDisciplines.name,
      group_ids: defaultValue.map((e: any) => e.id),
    });
    return () => {
      reset();
    };
  }, [currentDisciplines]);

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div style={{ marginBottom: "10px" }}>Вы изменяете название дисциплины {currentDisciplines.name}</div>
      <div style={{ marginBottom: "10px" }}>Введите новое название дисциплины:</div>
      <input
        className="input__input "
        type="text"
        placeholder="Название дисциплины"
        {...register("name", requiredField)}
      />
      {errors.name && <div className="input__error">{errors.name.message}</div>}
      <div style={{ marginBottom: "10px", marginTop: "20px" }}>Привязанные группы:</div>
      <SelectInputMulti data={groupsForInput} name="group_ids" control={control} />
      {errors.group_ids && <div className="input__error">{errors.group_ids.message}</div>}
      <div style={{ display: "flex", alignItems: "center", marginTop: "20px" }}>
        <Button htmlType="button" onClick={closeModal}>
          Отмена
        </Button>
        <Button htmlType="submit" style={{ marginLeft: "10px" }} type="primary">
          Изменить
        </Button>
      </div>
    </form>
  );
};

export default DisciplinesEditModal;
