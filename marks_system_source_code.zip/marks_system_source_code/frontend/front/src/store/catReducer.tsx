import { createSlice, PayloadAction } from "@reduxjs/toolkit";

import { loadingStatus } from "./appReducer";
import { catAPI, groupsAPI } from "../api/api";

export interface InitialStateType {
  listCat: Array<{ key: number; id: number; name: string }>;
}

const initialState: InitialStateType = {
  listCat: [],
};

export const catReducer = createSlice({
  name: "cat",
  initialState,
  reducers: {
    setCatList: (state, action: PayloadAction<Array<{ key: number; id: number; name: string }>>) => {
      state.listCat = action.payload;
    },
  },
});

export const { setCatList } = catReducer.actions;

export const getCat = (id?: number) => async (dispatch: any) => {
  dispatch(loadingStatus(true));

  try {
    if (id){
      const { data } = await catAPI.getCat(id);
      dispatch(
        setCatList(
          data.map((e: any) => ({
            key: e.id,
            id: e.id,
            name: e.name,
          }))
        )
      );
    } else {
      dispatch(
        setCatList(
          []
        )
      );
    }
  
  } catch (err: any) {
    console.error(err);
  }

  dispatch(loadingStatus(false));
};

export default catReducer.reducer;
