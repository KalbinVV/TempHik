import { Button } from "antd";
import React from "react";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { logOut } from "../../store/authReducer";

const Profile = () => {
  const dispatch = useAppDispatch();

  const userType = useAppSelector((state) => state.auth.userType);
  const fullName = useAppSelector((state) => state.auth.fullName);
  const myGroups = useAppSelector((state) => state.groups.myGroups);
  console.log(myGroups);
  const onLogOut = () => {
    dispatch(logOut());
  };

  return (
    <div className="profile">
      <div className="profile__title _h3">Профиль</div>
      <ul className="profile__list">
        <li className="profile__item">
          <span>Тип учетной записи: </span>
          <span>
            {(userType === 2 && "Администратор") || (userType === 1 && "Учитель") || (userType === 0 && "Студент")}
          </span>
        </li>
        <li className="profile__item">
          <span>Полное имя: </span>
          <span>{fullName}</span>
        </li>
        {userType !== 2 && (
          <li className="profile__item">
            <span>Мои группы: </span>
            <ul>
              {myGroups.map((e: any) => (
                <li>{e.name}</li>
              ))}
            </ul>
          </li>
        )}
      </ul>

      <Button onClick={onLogOut} danger>
        Выйти
      </Button>
    </div>
  );
};

export default Profile;
