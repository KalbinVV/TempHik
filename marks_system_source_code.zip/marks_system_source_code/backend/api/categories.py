from typing import Annotated

from sqlalchemy.orm import Session

import models
from app import App
from decorators.security_decorators import privilege_level_required

from fastapi import Request, Body, HTTPException


@App.post('/categories/category',
          summary='Добавить новую категорию',
          tags=['Категории'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def add_new_category(_request: Request,
                     group_id: Annotated[int, Body()],
                     name: Annotated[str, Body()]):
    with Session(models.engine) as session:
        if not session.query(models.Group).get(group_id):
            raise HTTPException(status_code=400,
                                detail='Неправильный ID группы!')

        category = models.Category(group_id=group_id,
                                   name=name)

        session.add(category)
        session.commit()

        return {'category_id': category.id}


@App.put('/categories/category',
         summary='Обновить имя категории',
         tags=['Категории'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def update_category(_request: Request,
                    category_id: Annotated[int, Body()],
                    name: Annotated[str, Body()]):
    with Session(models.engine) as session:
        category = session.query(models.Category).get(category_id)

        if category is None:
            raise HTTPException(status_code=400,
                                detail='Неправильный ID категории!')

        category.name = name

        session.commit()

        return {'ok': True}


@App.get('/categories/group_list',
         summary='Получить категории группы',
         tags=['Категории'])
@privilege_level_required(minimal_level=models.UserType.Teacher)
def get_group_categories(_request: Request,
                         group_id: int):
    with Session(models.engine) as session:
        group = session.query(models.Group).get(group_id)

        if group is None:
            raise HTTPException(status_code=400,
                                detail='Неправильный ID группы!')

        return [{'id': category.id,
                 'name': category.name} for category in group.categories]


@App.put('/categories/remove_category',
         summary='Удалить категорию',
         tags=['Категории'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def remove_category(_request: Request,
                    category_id: int):
    with Session(models.engine) as session:
        session.query(models.Category).filter_by(id=category_id).delete()

        session.commit()

        return {'ok': True}
