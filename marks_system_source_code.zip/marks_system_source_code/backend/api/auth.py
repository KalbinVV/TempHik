import hashlib
from typing import Annotated

from fastapi import Request, HTTPException, Body
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

import models
from app import App
from decorators.auth_decorators import auth_required
from decorators.security_decorators import privilege_level_required
from utils.auth_utils import make_token, get_user_by_request, get_user_id_by_request
from utils.users_util import get_dict_from_user_model


@App.post('/auth/login',
          summary='Войти в учётную запись',
          tags=['Авторизация'])
def auth(login: Annotated[str, Body()],
         password: Annotated[str, Body()]):
    hashed_password = hashlib.sha256(password.encode()).hexdigest()

    with Session(models.engine) as session:
        user = session.query(models.User).filter_by(login=login,
                                                    hashed_password=hashed_password).first()

        if user is None:
            raise HTTPException(status_code=403,
                                detail='Неправильные данные для входа!')

        response = JSONResponse(get_dict_from_user_model(user))

        response.set_cookie('token', make_token(user))

        return response


@App.get('/auth/me',
         summary=['Получить текущего пользователя'],
         tags=['Авторизация'])
@auth_required
def get_me(request: Request):
    with Session(models.engine) as session:
        user = session.query(models.User).get(get_user_id_by_request(request))

        response = JSONResponse(get_dict_from_user_model(user))

        return response


@App.get('/auth/users',
         summary='Получить список пользователей',
         tags=['Авторизация'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def get_users_list(_request: Request):
    with Session(models.engine) as session:
        users = session.query(models.User).all()

        return [get_dict_from_user_model(user) for user in users]


@App.put('/users/remove_user',
         summary='Удалить пользователя',
         tags=['Авторизация'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def remove_user(_request: Request,
                user_id: Annotated[int, Body()]):
    with Session(models.engine) as session:
        session.query(models.User).filter_by(id=user_id).delete()

        session.commit()

        return {'ok': True}


@App.post('/auth/logout',
          summary='Выйти из учётной записи',
          tags=['Авторизация'])
def logout():
    response = JSONResponse({'ok': True})

    response.delete_cookie('token')

    return response


@App.post('/auth/register',
          summary='Создать новую учётную запись',
          tags=['Авторизация'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def register(request: Request,
             login: Annotated[str, Body()],
             password: Annotated[str, Body()],
             fullname: Annotated[str, Body()],
             user_type: Annotated[models.UserType, Body()],
             groups_ids: Annotated[list[int], Body()]):
    with Session(models.engine) as session:
        user = get_user_by_request(request)

        if user.user_type.value <= user_type.value:
            raise HTTPException(status_code=400,
                                detail='Вы не можете создать пользователя с правами доступами равным или больше ваших!')

        created_user = models.User(login=login,
                                   hashed_password=hashlib.sha256(password.encode()).hexdigest(),
                                   fullname=fullname,
                                   user_type=user_type)

        session.add(created_user)

        for group_id in groups_ids:
            group = session.query(models.Group).get(group_id)

            if group is None:
                raise HTTPException(status_code=400,
                                    detail='Неправильный ID группы!')

            created_user.groups.add(group)

        session.commit()

        return {'created_user_id': created_user.id}


@App.post('/auth/update_user',
          summary='Обновить пользователя',
          tags=['Авторизация'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def register(request: Request,
             user_id: Annotated[int, Body()],
             login: Annotated[str, Body()],
             password: Annotated[str, Body()],
             fullname: Annotated[str, Body()],
             user_type: Annotated[models.UserType, Body()],
             groups_ids: Annotated[list[int], Body()]):
    with Session(models.engine) as session:
        user = get_user_by_request(request)

        if user.user_type.value <= user_type.value:
            raise HTTPException(status_code=400,
                                detail='Вы не можете создать пользователя с правами доступами равным или больше ваших!')

        updated_user = session.query(models.User).get(user_id)

        if updated_user is None:
            raise HTTPException(status_code=400,
                                detail='Неправильный ID пользователя!')

        updated_user.login = login
        updated_user.hashed_password = hashlib.sha256(password.encode()).hexdigest()
        updated_user.full_name = fullname
        updated_user.user_type = user_type

        updated_user.groups.clear()

        for group_id in groups_ids:
            group = session.query(models.Group).get(group_id)

            if group is None:
                raise HTTPException(status_code=400,
                                    detail='Неправильный ID группы!')

            updated_user.groups.add(group)

        session.commit()

        return {'ok': True}


@App.get('/auth/user',
         summary='Получить информацию о пользователе',
         tags=['Авторизация'])
@privilege_level_required(minimal_level=models.UserType.Teacher)
def get_user(_request: Request,
             user_id: int):
    with Session(models.engine) as session:
        user = session.query(models.User).get(user_id)

        if user is None:
            raise HTTPException(status_code=404,
                                detail='Неправильный ID пользователя!')

        return get_dict_from_user_model(user)
