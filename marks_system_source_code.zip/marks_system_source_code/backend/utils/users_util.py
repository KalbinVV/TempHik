from typing import Any, Type

import models


def get_dict_from_user_model(user: models.User | Type[models.User]) -> dict[str, Any]:
    return {'user_id': user.id,
            'login': user.login,
            'user_type': user.user_type.value,
            'fullname': user.fullname,
            'groups': [{
                'id': group.id,
                'name': group.name
            } for group in user.groups]}

