import React from "react";
import { Link } from "react-router-dom";
import { MAIN_PATH } from "../../utils/const";
import { LaptopOutlined, MenuOutlined } from "@ant-design/icons";
import { Button } from "antd";
import { useAppDispatch } from "../../store/hooks";
import { setIsShowMenu } from "../../store/appReducer";
import logoImg from '../../images/photo_2024-06-03_23-29-02.jpg'

const Header = () => {
  const dispatch = useAppDispatch();

  const onShowMenu = () => {
    dispatch(setIsShowMenu(true));
    document.getElementById('body')?.classList.add('_fixed')
  };

  return (
    <div className="header">
      <div className="container">
        <div className="header__inner">
          <div className="header__logo-wrap">
            <Link to={MAIN_PATH} className="header__logo">
              <img src={logoImg} alt="лого" />
            </Link>
            <div className="header__logo-text">Личный кабинет студента Соль-Илецкого индустриально-технологического техникума</div>
          </div>
          <Button onClick={onShowMenu} className="header__burger" icon={<MenuOutlined />}></Button>
        </div>
      </div>
    </div>
  );
};

export default Header;
