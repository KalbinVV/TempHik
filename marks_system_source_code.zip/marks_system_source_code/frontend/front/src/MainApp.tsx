import React, { useEffect, useState } from "react";
import "./App.scss";
import { useAppDispatch } from "./store/hooks";
import { initializeApp, setIsShowMenu, setTypeApp } from "./store/appReducer";
import { RouterProvider, useLocation } from "react-router-dom";
import router from "./routes";
import { typeAppDesktop, typeAppMobile } from "./utils/const";

function App() {
  const dispatch = useAppDispatch();

  const [width, setWidth] = useState<number>(window.innerWidth);

  const routers = router;

  useEffect(() => {
    if (width < 769) {
      dispatch(setTypeApp(typeAppMobile));
    }
    dispatch(initializeApp());
  }, [dispatch]);

  window.onresize = () => {
    setWidth(window.innerWidth);
    if (width < 769) {
      dispatch(setTypeApp(typeAppMobile));
    } else {
      dispatch(setTypeApp(typeAppDesktop));
    }
  };

  return <RouterProvider router={routers} />;
}

export default App;
