import { configureStore } from "@reduxjs/toolkit";
import authReducer from "./authReducer";
import appReducer from "./appReducer";
import groupReducer from "./groupReducer";
import userReducer from "./userReducer";
import disciplinesReducer from "./disciplinesReducer";
import catReducer from "./catReducer";
import marksReducer from "./marksReducer";

export const store = configureStore({
  reducer: {
    auth: authReducer,
    app: appReducer,
    groups: groupReducer,
    users: userReducer,
    disciplines: disciplinesReducer,
    cat: catReducer,
    marks: marksReducer
  },
  middleware: (getDefaultMiddleware) => getDefaultMiddleware(),
});

export type RootState = ReturnType<typeof store.getState>;

export type AppDispatch = typeof store.dispatch;

// @ts-ignore
window.store = store;
