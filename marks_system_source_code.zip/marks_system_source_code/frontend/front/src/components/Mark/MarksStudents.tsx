import React from "react"
import { useAppSelector } from "../../store/hooks";
import { Table, TableColumnsType } from "antd";
import { Link } from "react-router-dom";
import { MARKS_PATH } from "../../utils/const";


interface DataType {
  id: number;
  name: string;
}

const MarksStudents = () => {

  const myGroup = useAppSelector((state) => state.groups.myGroups);

  const columns: TableColumnsType<DataType> = [
    {
      title: "Группа",
      key: "name",
      render: (a)=> <Link to={`${MARKS_PATH}/${a.id}`}>{a.name}</Link>
    }
  ];

  return (
    <div>
      <div className="profile__title _h3">Оценки</div>
      <div className="marks__info-text-2">
        Выбрите группу для которой показать оценки
      </div>
      <Table
        title={() => <div className="_h4">Группы </div>}
        className="profile__table"
        dataSource={myGroup}
        columns={columns}
        pagination={false}
      />
    </div>
  )
};

export default MarksStudents;
