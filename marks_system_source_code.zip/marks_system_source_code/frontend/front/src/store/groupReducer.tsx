import { createSlice, PayloadAction } from "@reduxjs/toolkit";

import { loadingStatus } from "./appReducer";
import { groupsAPI } from "../api/api";

export interface InitialStateType {
  listGroup: Array<{ key: number; id: number; name: string }>;
  groupName: string | null;
  groupId: number | null;
  usersGroup: Array<any>;
  myGroups: Array<{ key: number; id: number; name: string }>;
}

const initialState: InitialStateType = {
  listGroup: [],
  groupName: null,
  groupId: null,
  usersGroup: [],
  myGroups: [],
};

export const groupReducer = createSlice({
  name: "group",
  initialState,
  reducers: {
    setGroups: (state, action: PayloadAction<Array<{ key: number; id: number; name: string }>>) => {
      state.listGroup = action.payload;
    },
    setMyGroups: (state, action: PayloadAction<Array<{ key: number; id: number; name: string }>>) => {
      state.myGroups = action.payload;
    },
    setGroup: (state, action: PayloadAction<{ id: number; name: string }>) => {
      state.groupName = action.payload.name;
      state.groupId = action.payload.id;
    },
    setUsersGroup: (state, action: PayloadAction<Array<any>>) => {
      state.usersGroup = action.payload;
    },
  },
});

export const { setGroups, setGroup, setUsersGroup, setMyGroups } = groupReducer.actions;

export const getGroups = () => async (dispatch: any) => {
  dispatch(loadingStatus(true));

  try {
    const { data } = await groupsAPI.getList();

    dispatch(
      setGroups(
        data.map((e: any) => ({
          key: e.id,
          id: e.id,
          name: e.name,
        }))
      )
    );
  } catch (err: any) {
    console.error(err);
  }

  dispatch(loadingStatus(false));
};

export const getGroup = (id: number) => async (dispatch: any) => {
  dispatch(loadingStatus(true));

  try {
    const { data } = await groupsAPI.getGroup(id);

    dispatch(setGroup({ id: data.id, name: data.name }));
    dispatch(
      setUsersGroup(
        data.users.map((e: any) => ({
          key: e.user_id,
          id: e.user_id,
          name: e.fullname,
          userType: e.user_type,
          groups: e.groups,
          login: e.login,
        }))
      )
    );
  } catch (err: any) {
    console.error(err);
  }

  dispatch(loadingStatus(false));
};

export const getGroupStudents = (id: number) => async (dispatch: any) => {
  dispatch(loadingStatus(true));

  try {
    const { data } = await groupsAPI.getGroupStudents(id);
    dispatch(
      setUsersGroup(
        data.map((e: any) => ({
          key: e.user_id,
          id: e.user_id,
          name: e.fullname,
          userType: e.user_type,
          groups: e.groups,
          login: e.login,
        }))
      )
    );
  } catch (err: any) {
    console.error(err);
  }

  dispatch(loadingStatus(false));
};

export const getGroupOnlyStudents = (id: number) => async (dispatch: any) => {
  dispatch(loadingStatus(true));

  try {
    const { data } = await groupsAPI.getGroupStudents(id);
    let newArray:Array<any> = [];

    data.forEach((e: any) => {
      if (e.user_type === 0) {
        newArray.push({
          key: e.user_id,
          id: e.user_id,
          name: e.fullname,
          userType: e.user_type,
          groups: e.groups,
          login: e.login,
        });
      }
    });
    dispatch(setUsersGroup(newArray));
  } catch (err: any) {
    console.error(err);
  }

  dispatch(loadingStatus(false));
};

export default groupReducer.reducer;
