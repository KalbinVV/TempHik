import enum
import hashlib
from typing import Set

from sqlalchemy import String, Enum, ForeignKey, Date, Integer, create_engine, Float
from sqlalchemy.orm import declarative_base, Mapped, mapped_column, relationship, Session

DATABASE_URL = "postgresql+psycopg2://user:pass@db:5432/db"

engine = create_engine(DATABASE_URL)
Base = declarative_base()


class SecondariesDisciplineTable(Base):
    __tablename__ = 'disciplines_groups_secondary'

    id: Mapped[int] = mapped_column(primary_key=True)

    discipline_id: Mapped[int] = mapped_column(ForeignKey('disciplines.id', ondelete='CASCADE'), nullable=False)
    group_id: Mapped[int] = mapped_column(ForeignKey('groups.id', ondelete='CASCADE'), nullable=False)



# Ограничение по длине имени дисциплины
DISCIPLINE_NAME_LIMIT = 100


class Discipline(Base):
    __tablename__ = 'disciplines'

    id: Mapped[int] = mapped_column(primary_key=True)

    name: Mapped[str] = mapped_column(String(DISCIPLINE_NAME_LIMIT), nullable=False)
    groups: Mapped[Set['Group']] = relationship('Group',
                                                back_populates='disciplines',
                                                secondary=SecondariesDisciplineTable.__table__)


class SecondariesGroupsTable(Base):
    __tablename__ = 'users_groups_secondary'

    id: Mapped[int] = mapped_column(primary_key=True)

    user_id: Mapped[int] = mapped_column(ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    group_id: Mapped[int] = mapped_column(ForeignKey('groups.id', ondelete='CASCADE'), nullable=False)


#  Ограничение по длине имени группы
GROUP_NAME_LIMIT = 30


class Group(Base):
    __tablename__ = 'groups'

    id: Mapped[int] = mapped_column(primary_key=True)

    name: Mapped[str] = mapped_column(String(GROUP_NAME_LIMIT), nullable=False, unique=True)

    disciplines: Mapped[Set['Discipline']] = relationship('Discipline',
                                                          back_populates='groups',
                                                          secondary=SecondariesDisciplineTable.__table__)
    users: Mapped[Set['User']] = relationship('User',
                                              back_populates='groups',
                                              secondary=SecondariesGroupsTable.__table__)

    categories: Mapped[Set['Category']] = relationship('Category',
                                                       backref='Group')


class UserType(enum.Enum):
    Student = 0
    Teacher = 1
    Admin = 2


# Ограничение по длине логина
USER_LOGIN_LIMIT = 20
# Ограничение по длине ФИО
USER_FULLNAME_LIMIT = 40
# Ограничение по длине хэша пароля (256 - длина контрольной суммы SHA256)
USER_HASHED_PASSWORD_LIMIT = 256


class User(Base):
    __tablename__ = 'users'

    id: Mapped[int] = mapped_column(primary_key=True)

    login: Mapped[str] = mapped_column(String(USER_FULLNAME_LIMIT), nullable=False)
    fullname: Mapped[str] = mapped_column()
    # Хэш в SHA256
    hashed_password: Mapped[str] = mapped_column(String(USER_HASHED_PASSWORD_LIMIT), nullable=False)

    user_type: Mapped[UserType] = mapped_column(Enum(UserType), default=UserType.Student, nullable=False)

    groups: Mapped[Set['Group']] = relationship('Group',
                                                back_populates='users',
                                                secondary=SecondariesGroupsTable.__table__)


# Ограничение по длине имени категории
CATEGORY_NAME_LIMIT = 100


class Category(Base):
    __tablename__ = 'categories'

    id: Mapped[int] = mapped_column(primary_key=True)

    name: Mapped[str] = mapped_column(String(CATEGORY_NAME_LIMIT), nullable=False)
    group_id: Mapped[int] = mapped_column(ForeignKey('groups.id', ondelete='CASCADE'), nullable=False)

    group: Mapped['Group'] = relationship('Group',
                                          viewonly=True)


class DisciplineMarkType(enum.Enum):
    # Зачет
    Test = 'Test'
    # Дифференциальный зачет
    TestWithMark = 'TestWithMark'
    # Экзамен
    Exam = 'Exam'


class DisciplineMark(Base):
    __tablename__ = 'disciplines_marks'

    id: Mapped[int] = mapped_column(primary_key=True)

    percent: Mapped[float] = mapped_column(Float, nullable=False)
    type: Mapped[DisciplineMarkType] = mapped_column(Enum(DisciplineMarkType), nullable=False)

    category_id: Mapped[int] = mapped_column(ForeignKey('categories.id', ondelete='CASCADE'), nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    discipline_id: Mapped[int] = mapped_column(ForeignKey('disciplines.id', ondelete='CASCADE'), nullable=False)
    group_id: Mapped[int] = mapped_column(ForeignKey('groups.id', ondelete='CASCADE'), nullable=False)

    category: Mapped['Category'] = relationship('Category')
    user: Mapped['User'] = relationship('User')
    discipline: Mapped['Discipline'] = relationship('Discipline')
    group: Mapped['Group'] = relationship('Group')


def init_tables():
    Base.metadata.create_all(engine)

    # Добавляем учётную запись администратора, если её нет
    with Session(engine) as session:
        root_user = session.query(User).filter_by(login='root').first()

        if root_user is None:
            root_user = User(login='root',
                             hashed_password=hashlib.sha256('root'.encode()).hexdigest(),
                             fullname='Администратор',
                             user_type=UserType.Admin)

            session.add(root_user)
            session.commit()

