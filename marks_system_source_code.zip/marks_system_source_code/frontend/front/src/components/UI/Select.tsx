import { Select } from "antd";
import React from "react";
import { Controller } from "react-hook-form";

const SelectInput = ({
  control,
  data,
  placeholder,
  name,
  showSearch
}: {
  control: any;
  name: string;
  placeholder?: string;
  showSearch?:boolean;
  data?: Array<{ value: number|string; label: string }>;
}) => {

  const filterOption = (input: string, option?: { label: string; value: string }) =>
    (option?.label ?? '').toLowerCase().includes(input.toLowerCase());

  return (
    <Controller
      control={control}
      name={name}
      rules={{
        required: "Поле обязательно для заполнение",
      }}
      render={({ field }) => (
        <>
          <Select
            {...field}
            className="ant-select"
            options={data}
           
            showSearch={showSearch?showSearch: false}
            //@ts-ignore
            filterOption={filterOption}
            listHeight={130}
            placeholder={placeholder ? placeholder : "Выберите... "}
          />
        </>
      )}
    />
  );
};

export default SelectInput;
