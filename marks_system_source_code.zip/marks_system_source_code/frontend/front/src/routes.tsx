import { createBrowserRouter } from "react-router-dom";
import App from "./components/App/App";
import Error from "./components/404/404";
import Login from "./components/Login/Login";
import {
  DISCIPLINES_PATH,
  ERROR_PATH,
  GROUP_CAT_PATH,
  GROUP_PATH,
  LOGIN_PATH,
  MAIN_PATH,
  MANAGER_PATH,
  MARKS_PATH,
  USERS_ADD_PATH,
  USERS_PATH,
} from "./utils/const";
import MainLayout from "./layout/MainLayout";
import Profile from "./components/Profile/Profile";
import Manager from "./components/Manager/Manager";
import Groups from "./components/Manager/Group/Groups";
import Users from "./components/Manager/User/Users";
import ManagerLayout from "./components/Manager/ManagerLayout";
import UsersAdd from "./components/Manager/User/UsersAdd";
import UsersEdit from "./components/Manager/User/UsersEdit";
import Group from "./components/Manager/Group/Group";
import Disciplines from "./components/Manager/Disciplines/Disciplines";
import GroupCat from "./components/Manager/Group/GroupCat";
import Discipline from "./components/Manager/Disciplines/Discipline";
import Marks from "./components/Mark/Marks";
import MarksList from "./components/Mark/MarkList";

const router = createBrowserRouter([
  {
    path: MAIN_PATH,
    element: <MainLayout />,
    errorElement: <Error />,

    children: [
      {
        path: MAIN_PATH,
        element: <App />,
        children: [
          {
            path: MAIN_PATH,
            element: <Profile />,
          },
          {
            path: MANAGER_PATH,
            element: <ManagerLayout />,
            children: [
              {
                path: MANAGER_PATH,
                element: <Manager />,
              },
              {
                path: GROUP_PATH,
                element: <Groups />,
              },
              {
                path: `${GROUP_PATH}/:id`,
                element: <Group />,
              },
              {
                path: `${GROUP_CAT_PATH}/:id`,
                element: <GroupCat />,
              },
              {
                path: USERS_PATH,
                element: <Users />,
              },
              {
                path: USERS_ADD_PATH,
                element: <UsersAdd />,
              },
              {
                path: `${USERS_PATH}/:id`,
                element: <UsersEdit />,
              },
              {
                path: DISCIPLINES_PATH,
                element: <Disciplines />,
              },
              {
                path: `${DISCIPLINES_PATH}/:id`,
                element: <Discipline />,
              },
            ],
          },
          {
            path: MARKS_PATH,
            element: <Marks />,
          },
          {
            path: `${MARKS_PATH}/:id`,
            element: <MarksList />,
          },
        ],
      },
      {
        path: LOGIN_PATH,
        element: <Login />,
      }
    ],
  },

  {
    path: ERROR_PATH,
    element: <Error />,
  },
]);

export default router;
