import { Button } from "antd";
import React, { useEffect } from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import { requiredField } from "../../../utils/validators/validators";
import SelectInput from "../../UI/Select";
import SelectInputMulti from "../../UI/SelectMulti";
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import {  getGroups } from "../../../store/groupReducer";
import { authAPI } from "../../../api/api";
import { openErrorNotification, openSuccessNotification } from "../../../utils/Notification";
import { useNavigate } from "react-router-dom";

type Inputs = {
  login: string;
  password: string;
  fullname: string;
  user_type: number;
  groups_ids: Array<number>;
};

const UsersAdd = () => {
  const groups = useAppSelector((state) => state.groups.listGroup);

  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const groupsForInput = groups.map((e: { id: number; name: string }) => ({
    value: e.id,
    label: e.name,
  }));

  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<Inputs>({
    defaultValues: { user_type: 0 },
  });

  const onSubmit: SubmitHandler<Inputs> = async (dataForm) => {
    try {
      const { data } = await authAPI.register(dataForm);
      openSuccessNotification('Успешное создание пользователя')
    } catch (e: any) {
      console.error(e)
      openErrorNotification('Ошибка создание пользователя')
    }
  };

  useEffect(() => {
    dispatch(getGroups());
  }, []);

  return (
    <div className="profile">
        <Button className="profile__top-btn" onClick={() => navigate(-1)}>
        Назад
      </Button>
      <div className="profile__title _h3">Добавление пользователей</div>
      <section className="login">
        <div className="container">
          <form className="login__wrap">
            <div className="login__title _h3">Регистрация пользователя</div>
            <div className="login__inner">
              <div className="login__input-wrap input">
                <label className="input__label" htmlFor="name">
                  Имя*
                </label>
                <input
                  {...register("login", requiredField)}
                  className="input__input"
                  type="text"
                  placeholder="Логин"
                  id="name"
                />
                {errors.login && <div className="input__error">{errors.login.message}</div>}
              </div>
              <div className="login__input-wrap input">
                <label className="input__label" htmlFor="pass">
                  Пароль*
                </label>
                <input
                  {...register("password", requiredField)}
                  className="input__input"
                  type="password"
                  placeholder="Пароль"
                  id="pass"
                />
                {errors.password && <div className="input__error">{errors.password.message}</div>}
              </div>
              <div className="login__input-wrap input">
                <label className="input__label" htmlFor="fullname">
                  Полное имя*
                </label>
                <input
                  {...register("fullname", requiredField)}
                  className="input__input"
                  type="text"
                  placeholder="Полное имя"
                  id="fullname"
                />
                {errors.fullname && <div className="input__error">{errors.fullname.message}</div>}
              </div>
              <div className="login__input-wrap input">
                <label className="input__label" htmlFor="user_type">
                  Тип пользователя*
                </label>

                <SelectInput
                  data={[
                    { value: 0, label: "Студент" },
                    { value: 1, label: "Учитель" },
                  ]}
                  name="user_type"
                  control={control}
                />

                {errors.user_type && <div className="input__error">{errors.user_type.message}</div>}
              </div>
              <div className="login__input-wrap input">
                <label className="input__label" htmlFor="groups_ids">
                  Группы*
                </label>

                <SelectInputMulti data={groupsForInput} name="groups_ids" control={control} />

                {errors.groups_ids && <div className="input__error">{errors.groups_ids.message}</div>}
              </div>
            </div>
            <Button className="login__btn" type="primary" onClick={handleSubmit(onSubmit)}>
              Зарегистрировать
            </Button>
          </form>
        </div>
      </section>
    </div>
  );
};

export default UsersAdd;
