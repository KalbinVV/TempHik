import React, { useEffect } from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import { openErrorNotification, openSuccessNotification } from "../../../utils/Notification";
import { Button } from "antd";
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import { getUsers } from "../../../store/userReducer";
import SelectInput from "../../UI/Select";
import { groupsAPI } from "../../../api/api";

type addUserGroup = {
  userId: number;
};

const AddUserGroup = ({ fetch, closeModal, groupId }: any) => {
  const users = useAppSelector((state) => state.users.listUsers);
  const dispatch = useAppDispatch();

  const usersForInput = users.map((e: any) => ({
    value: e.id,
    label: e.name,
  }));

  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors },
  } = useForm<addUserGroup>();

  const onSubmit: SubmitHandler<addUserGroup> = async (data) => {
    try {
      await groupsAPI.addUserGroup(data.userId, groupId);
      reset();
      await fetch();
      closeModal();
      openSuccessNotification("Успешное добавление пользователя в группу");
    } catch (e: any) {
      openErrorNotification("Ошибка добавления пользователя в группу");
    }
  };

  useEffect(() => {
    dispatch(getUsers());
  }, []);
  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div style={{ marginBottom: "10px" }}>Выберите пользователя:</div>
      <SelectInput data={usersForInput} name="userId" control={control} showSearch={true} />
      {errors.userId && <div className="input__error">{errors.userId.message}</div>}
      <div style={{ display: "flex", alignItems: "center", marginTop: "20px" }}>
        <Button htmlType="button" onClick={closeModal}>
          Отмена
        </Button>
        <Button htmlType="submit" style={{ marginLeft: "10px" }} type="primary">
          Добавить
        </Button>
      </div>
    </form>
  );
};

export default AddUserGroup;
