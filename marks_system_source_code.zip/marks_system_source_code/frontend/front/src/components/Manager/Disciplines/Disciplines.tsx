import React, { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import { Button, Modal, Table, TableColumnsType } from "antd";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import {  useNavigate } from "react-router-dom";
import { openErrorNotification, openSuccessNotification } from "../../../utils/Notification";
import { disciplinesAPI } from "../../../api/api";
import { getDisciplines } from "../../../store/disciplinesReducer";
import DisciplineAddModal from "../modal/DisciplineAddModal";
import DisciplinesEditModal from "../modal/DisciplinesEditModal";
import { typeAppMobile } from "../../../utils/const";

interface DataType {
  id: number;
  name: string;
  groups: Array<{id:number, name: string}>
}

const Disciplines = () => {
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [isModalDelOpen, setIsModalDelOpen] = useState<boolean>(false);
  const [isModalEditOpen, setIsModalEditOpen] = useState<boolean>(false);
  const [currentDisciplines, setCurrentDisciplines] = useState<{ id: number; name: string, groups: Array<any> } | null>(null);
  const disciplines = useAppSelector((state) => state.disciplines.listDisciplines);
  const isMob = useAppSelector((state) => state.app.typeApp);

  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const onFetch = async () => {
    dispatch(getDisciplines());
    setCurrentDisciplines(null)
  };
  const showModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setIsModalDelOpen(false);
    setIsModalEditOpen(false);
   // setIsModalManageOpen(false)
    setCurrentDisciplines(null);
  };

  const delModal = async () => {
    try {
      if (currentDisciplines) {
        const { data } = await disciplinesAPI.removeDiscipline(currentDisciplines.id);
        openSuccessNotification("Дисциплина удалена");
        navigate(0);
      }
    } catch (e) {
      console.error(e);
      openErrorNotification("Ошибка при удаление дисциплины");
    }
    setCurrentDisciplines(null);
  };

  const columns: TableColumnsType<DataType> = [
    {
      title: "Название дицсциплины",
      key: "name",
      dataIndex: "name",
      //render: (a) => <Link to={`${a.id}`}>{a.name}</Link>,
    },
    {
      title: "Управление",
      dataIndex: "",
      width: "120px",
      render: (a) => (
        <div className="table__inner">
          <Button
            onClick={() => {
              setIsModalDelOpen(true);
              setCurrentDisciplines({ id: a.id, name: a.name, groups: a.groups });
            }}
            className="table__btn _del"
            danger
          >
            <DeleteOutlined />
          </Button>
          <Button
            onClick={() => {
              setIsModalEditOpen(true);
              setCurrentDisciplines({ id: a.id, name: a.name, groups: a.groups });
            }}
            className="table__btn _edit"
          >
            <EditOutlined />
          </Button>
          {/* <Button
            onClick={() => {
              setIsModalManageOpen(true);
              setCurrentDisciplines({ id: a.id, name: a.name });
            }}
            className="table__btn  _green"
          >
            <LinkOutlined />
          </Button> */}
        </div>
      ),
    },
  ];

  useEffect(() => {
    onFetch();
  }, []);

  return (
    <div className="profile">
      {isMob === typeAppMobile && (
        <Button className="profile__top-btn" onClick={() => navigate(-1)}>
          Назад
        </Button>
      )}
      <div className="profile__title _h3">Управления дисциплинами</div>
      <Button type="primary" onClick={showModal}>
        Добавить дисциплину
      </Button>

      <Table className="profile__table" dataSource={disciplines} columns={columns} pagination={false} />

      <Modal title="Добавление дисциплины" open={isModalOpen} footer={null} onOk={closeModal} onCancel={closeModal}>
        <DisciplineAddModal fetch={onFetch} closeModal={closeModal} />
      </Modal>

      <Modal
        title="Удаление дисциплины"
        open={isModalDelOpen}
        onOk={delModal}
        onCancel={closeModal}
        okType="danger"
        okText="Удалить"
        cancelText="Закрыть"
      >
        Хотите удалить дисциплину {currentDisciplines?.name}?
      </Modal>

      <Modal
        title="Редактирование дисциплины"
        open={isModalEditOpen}
        footer={null}
        onOk={closeModal}
        onCancel={closeModal}
      >
        <DisciplinesEditModal fetch={onFetch} currentDisciplines={currentDisciplines} closeModal={closeModal} defaultValue={currentDisciplines?.groups} />
      </Modal>
      {/* <Modal
        title="Управлениями группами"
        open={isModalManageOpe}
        footer={null}
        onOk={closeModal}
        onCancel={closeModal}
      >
        <DisciplinesManagerModal fetch={fetch} currentDisciplines={currentDisciplines} closeModal={closeModal} />
      </Modal> */}
    </div>
  );
};

export default Disciplines;
