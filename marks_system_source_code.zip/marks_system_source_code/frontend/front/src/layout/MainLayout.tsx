import React from "react";
import { useAppSelector } from "../store/hooks";
import Loading from "../components/Loading/Loading";
import Header from "../components/Header/Header";
import { Outlet } from "react-router-dom";

const MainLayout = () => {
  const loading = useAppSelector((state) => state.app.loading);
  const isInit = useAppSelector((state) => state.app.init);

  if (!isInit) {
    return <Loading />;
  }

  return (
    <>
      {loading ? <Loading /> : ""}
      <Header />

      <main className="main">
        <Outlet />
      </main>
    </>
  );
};

export default MainLayout;
