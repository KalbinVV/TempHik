import React, { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import { getGroup } from "../../../store/groupReducer";
import { Button, Modal, Table, TableColumnsType } from "antd";
import { DeleteOutlined } from "@ant-design/icons";
import { openErrorNotification, openSuccessNotification } from "../../../utils/Notification";
import { groupsAPI } from "../../../api/api";
import AddUserGroup from "../modal/AddUserGroup";
import { GROUP_CAT_PATH } from "../../../utils/const";

interface DataType {
  id: number;
  name: string;
  userType: number;
  groups: Array<any>;
}

const Group = () => {
  const params = useParams<{ id: string }>();
  const usersGroup = useAppSelector((state) => state.groups.usersGroup);
  const groupName = useAppSelector((state) => state.groups.groupName);
  const [isModalDelOpen, setIsModalDelOpen] = useState<boolean>(false);
  const [isModalAddOpen, setIsModalAddOpen] = useState<boolean>(false);
  const [currentUser, setCurrentUser] = useState<{ id: number; name: string } | null>(null);

  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const columns: TableColumnsType<DataType> = [
    {
      title: "Имя",
      key: "name",
      dataIndex: "name",
    },
    {
      title: "Тип",
      key: "userType",
      render: (a) => (
        <div>
          {a.userType === 0 && "Студент"}
          {a.userType === 1 && "Преподователь"}
          {a.userType === 2 && "Администратор"}
        </div>
      ),
    },
    {
      title: "Открепить",
      width: "102px",
      render: (a) => (
        <div className="table__inner" style={{ justifyContent: "center" }}>
          <Button
            onClick={() => {
              setIsModalDelOpen(true);
              setCurrentUser({ id: a.id, name: a.name });
            }}
            className="table__btn _del"
            danger
          >
            <DeleteOutlined />
          </Button>
        </div>
      ),
    },
  ];

  const closeModal = () => {
    setIsModalDelOpen(false);
    setIsModalAddOpen(false);
    setCurrentUser(null);
  };

  const removeUser = async () => {
    try {
      if (currentUser) {
        const { data } = await groupsAPI.removeUserGroup(currentUser.id, Number(params.id));
        openSuccessNotification("Пользователь откреплен");
        onFetch();
      }
    } catch (e) {
      console.error(e);
      openErrorNotification("Ошибка при открепление");
    }
    setIsModalDelOpen(false);
    setCurrentUser(null);
  };

  const onFetch = () => {
    dispatch(getGroup(Number(params.id)));
  };

  useEffect(() => {
    onFetch();
  }, []);

  return (
    <div className="profile">
      <Button className="profile__top-btn" onClick={() => navigate(-1)}>
        К списку групп
      </Button>
      <div className="profile__title _h3">Управление группой {groupName} </div>
      <Button type="primary" onClick={() => setIsModalAddOpen(true)}>
        Добавить в группу
      </Button>
      <div style={{marginTop: '15px'}}>
      <Link className="btn" to={`${GROUP_CAT_PATH}/${params.id}`}>
        Редактировать семестры
      </Link>
      </div>

      <Table
        title={() => <div className="_h4">Состав группы {groupName}</div>}
        className="profile__table"
        dataSource={usersGroup}
        columns={columns}
        pagination={false}
      />

      <Modal
        title="Открепить от группы"
        open={isModalDelOpen}
        onOk={removeUser}
        onCancel={closeModal}
        okType="danger"
        okText="Открепить"
        cancelText="Закрыть"
      >
        Хотите открепить от группы {currentUser?.name}?
      </Modal>

      <Modal
        title="Добавление пользователя в группу"
        open={isModalAddOpen}
        footer={null}
        onOk={closeModal}
        onCancel={closeModal}
      >
        <AddUserGroup fetch={onFetch} closeModal={closeModal} groupId={Number(params.id)} />
      </Modal>
    </div>
  );
};

export default Group;
