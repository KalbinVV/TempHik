import React from "react";
import { useAppSelector } from "../../store/hooks";
import MarksStudents from "./MarksStudents";
import MarksManager from "./MarksManager";

const Marks = () => {
  const typeUser = useAppSelector((state) => state.auth.userType);

  return <>{typeUser === 0 ? <MarksStudents /> : <MarksManager />}</>;
};

export default Marks;
