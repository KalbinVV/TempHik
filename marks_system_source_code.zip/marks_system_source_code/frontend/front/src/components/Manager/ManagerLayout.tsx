import React from "react";
import { useAppSelector } from "../../store/hooks";
import {  Navigate, Outlet } from "react-router-dom";
import { MAIN_PATH } from "../../utils/const";

const ManagerLayout = () => {
  const typeUser = useAppSelector((state) => state.auth.userType);

  if (typeUser !== 2) {
    return <Navigate to={MAIN_PATH}></Navigate>;
  }
  return (
    <Outlet/>
  );
};

export default ManagerLayout;
