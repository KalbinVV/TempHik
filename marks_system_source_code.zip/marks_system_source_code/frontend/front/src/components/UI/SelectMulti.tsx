import { Select } from "antd";
import React from "react";
import { Controller } from "react-hook-form";

const SelectInputMulti = ({
  control,
  data,
  placeholder,
  name,
}: {
  control: any;
  name: string;
  placeholder?: string;
  data?: Array<{ value: number; label: string }>;
}) => {
  return (
    <Controller
      control={control}
      name={name}
      rules={{
        required: "Поле обязательно для заполнение",
      }}
      render={({ field }) => (
        <>
          <Select
            {...field}
            mode="multiple"
            className="ant-select"
            options={data}
            listHeight={130}
            placeholder={placeholder ? placeholder : "Выберите... "}
          />
        </>
      )}
    />
  );
};

export default SelectInputMulti;
