import React, { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import { Button, Modal, Table, TableColumnsType } from "antd";
import GroupAddModal from "../modal/GroupAddModal";
import { getGroups } from "../../../store/groupReducer";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import GroupEditModal from "../modal/GroupEditModal";
import { Link, useNavigate } from "react-router-dom";
import { openErrorNotification, openSuccessNotification } from "../../../utils/Notification";
import { groupsAPI } from "../../../api/api";
import { typeAppMobile } from "../../../utils/const";

interface DataType {
  id: number;
  name: string;
}

const Groups = () => {
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [isModalDelOpen, setIsModalDelOpen] = useState<boolean>(false);
  const [isModalEditOpen, setIsModalEditOpen] = useState<boolean>(false);
  const [currentGroup, setCurrentGroup] = useState<{ id: number; name: string } | null>(null);
  const groups = useAppSelector((state) => state.groups.listGroup);
  const isMob = useAppSelector((state) => state.app.typeApp);

  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const fetch = async () => {
    dispatch(getGroups());
  };

  const showModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setIsModalDelOpen(false);
    setIsModalEditOpen(false);
    setCurrentGroup(null);
  };

  const delModal = async () => {
    try {
      if (currentGroup) {
        const { data } = await groupsAPI.removeGroup(currentGroup.id);
        openSuccessNotification("Группа удалена");
        navigate(0);
      }
    } catch (e) {
      console.error(e);
      openErrorNotification("Ошибка при удаление группы");
    }
    setCurrentGroup(null);
  };

  const columns: TableColumnsType<DataType> = [
    {
      title: "Название группы",
      key: "name",
      render: (a) => <Link to={`${a.id}`}>{a.name}</Link>,
    },
    {
      title: "Управление",
      dataIndex: "",
      width: "120px",
      render: (a) => (
        <div className="table__inner">
          <Button
            onClick={() => {
              setIsModalDelOpen(true);
              setCurrentGroup({ id: a.id, name: a.name });
            }}
            className="table__btn _del"
            danger
          >
            <DeleteOutlined />
          </Button>
          <Button
            onClick={() => {
              setIsModalEditOpen(true);
              setCurrentGroup({ id: a.id, name: a.name });
            }}
            className="table__btn _edit"
          >
            <EditOutlined />
          </Button>
        </div>
      ),
    },
  ];

  useEffect(() => {
    fetch();
  }, []);

  return (
    <div className="profile">
      {isMob === typeAppMobile && (
        <Button className="profile__top-btn" onClick={() => navigate(-1)}>
          Назад
        </Button>
      )}
      <div className="profile__title _h3">Управлениями группами</div>
      <Button type="primary" onClick={showModal}>
        Добавить группу
      </Button>

      <Table className="profile__table" dataSource={groups} columns={columns} pagination={false} />

      <Modal title="Добавление группы" open={isModalOpen} footer={null} onOk={closeModal} onCancel={closeModal}>
        <GroupAddModal fetch={fetch} closeModal={closeModal} />
      </Modal>

      <Modal
        title="Удаление группы"
        open={isModalDelOpen}
        onOk={delModal}
        onCancel={closeModal}
        okType="danger"
        okText="Удалить"
        cancelText="Закрыть"
      >
        Хотите удалить группу {currentGroup?.name}?
      </Modal>

      <Modal title="Редактирование группы" open={isModalEditOpen} footer={null} onOk={closeModal} onCancel={closeModal}>
        <GroupEditModal fetch={fetch} currentGroup={currentGroup} closeModal={closeModal} />
      </Modal>
    </div>
  );
};

export default Groups;
