import React, { useEffect } from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import { requiredField } from "../../../utils/validators/validators";
import { Button } from "antd";
import { disciplinesAPI } from "../../../api/api";
import { openErrorNotification, openSuccessNotification } from "../../../utils/Notification";
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import { getGroups } from "../../../store/groupReducer";
import SelectInputMulti from "../../UI/SelectMulti";

type addGroup = {
  group_ids: string;
};

const DisciplinesManagerModal = ({ fetch, closeModal, currentDisciplines }: any) => {
  const groups = useAppSelector((state) => state.groups.listGroup);

  const groupsForInput = groups.map((e: { id: number; name: string }) => ({
    value: e.id,
    label: e.name,
  }));

  const dispatch = useAppDispatch();

  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors },
  } = useForm<addGroup>();

  const onSubmit: SubmitHandler<addGroup> = async (data) => {
    try {
      console.log(data);
    //  await disciplinesAPI.editDiscipline(currentDisciplines.id, data.name);
      reset();
      await fetch();
      closeModal();
      openSuccessNotification("Успешное изменение групп дисциплины");
    } catch (e: any) {
      openErrorNotification("Ошибка изменение  групп дисциплины");
    }
  };

  useEffect(() => {
    dispatch(getGroups());
  }, []);

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div style={{ marginBottom: "10px" }}>Выбранная дисциплины {currentDisciplines.name}</div>
      <div style={{ marginBottom: "10px" }}>Веберите группы:</div>
      <SelectInputMulti data={groupsForInput} name="group_ids" control={control} />
      {errors.group_ids && <div className="input__error">{errors.group_ids.message}</div>}
      <div style={{ display: "flex", alignItems: "center", marginTop: "20px" }}>
        <Button htmlType="button" onClick={closeModal}>
          Отмена
        </Button>
        <Button htmlType="submit" style={{ marginLeft: "10px" }} type="primary">
          Изменить
        </Button>
      </div>
    </form>
  );
};

export default DisciplinesManagerModal;
