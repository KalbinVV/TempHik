import { createSlice, PayloadAction } from "@reduxjs/toolkit";

import { loadingStatus } from "./appReducer";
import { disciplinesAPI, groupsAPI, marksAPI } from "../api/api";

type semestrType = {
  name: string;
  id: number;
  marks: Array<{ discipline: { id: number; name: string }; type: string; parcent: number }>;
};

export interface InitialStateType {
  listMarks: Array<semestrType>;
}

const initialState: InitialStateType = {
  listMarks: [],
};

export const marksReducer = createSlice({
  name: "marks",
  initialState,
  reducers: {
    setMarks: (state, action: PayloadAction<Array<semestrType>>) => {
      state.listMarks = action.payload;
    },
    removeMarks: (state) => {
      state.listMarks = [];
    },
  },
});

export const { setMarks, removeMarks } = marksReducer.actions;

export const getUserMark = (user_id: number, group_id: number) => async (dispatch: any) => {
  dispatch(loadingStatus(true));

  try {
    const { data } = await marksAPI.getUserMark(user_id, group_id);
    dispatch(
      setMarks(data)
    );
  } catch (err: any) {
    console.error(err);
  }

  dispatch(loadingStatus(false));
};

export const getMyMark = (id?: number) => async (dispatch: any) => {
  dispatch(loadingStatus(true));

  try {
    if (id) {
      const { data } = await marksAPI.getMyMark(id);
      dispatch(
        setMarks(data)
      );
    } else {
      dispatch(setMarks([]));
    }
  } catch (err: any) {
    console.error(err);
  }

  dispatch(loadingStatus(false));
};

export default marksReducer.reducer;
