import React from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import { requiredField } from "../../../utils/validators/validators";
import { Button } from "antd";
import { catAPI } from "../../../api/api";
import { openErrorNotification, openSuccessNotification } from "../../../utils/Notification";

type addCat = {
  name: string;
};

const CatAddModal = ({ fetch, closeModal, id }: any) => {

 
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<addCat>();

  const onSubmit: SubmitHandler<addCat> = async (data) => {
    try {
      console.log(data);
      await catAPI.addCat(id, data.name);
      reset();
      await fetch();
      closeModal();
      openSuccessNotification("Успешное добавление семестра");
    } catch (e: any) {
      openErrorNotification("Ошибка добавления семестра");
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div style={{ marginBottom: "10px" }}>Введите название Семестра:</div>
      <input className="input__input " type="text" placeholder="Название семестра" {...register("name", requiredField)} />
      {errors.name && <div className="input__error">{errors.name.message}</div>}
      <div style={{ display: "flex", alignItems: "center", marginTop: "20px" }}>
        <Button htmlType="button" onClick={closeModal}>
          Отмена
        </Button>
        <Button htmlType="submit" style={{ marginLeft: "10px" }} type="primary">
          Добавить
        </Button>
      </div>
    </form>
  );
};

export default CatAddModal;
