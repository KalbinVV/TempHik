from typing import Type, Any

import models


def get_dict_from_mark_model(mark: Type[models.DisciplineMark] | models.DisciplineMark) -> dict[str, Any]:
    return {
        'id': mark.id,
        'discipline': {
            'id': mark.discipline.id,
            'name': mark.discipline.name
        },
        'type': mark.type,
        'percent': mark.percent
    }
