import React, { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "antd";
import { getMyMark } from "../../store/marksReducer";

const MarksList = () => {
  const params = useParams<{ id: string }>();
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const marks = useAppSelector((state) => state.marks.listMarks);

  console.log(marks);

  useEffect(() => {
    dispatch(getMyMark(Number(params.id)));
  }, []);

  return (
    <div className="marks">
      <Button className="profile__top-btn" onClick={() => navigate(-1)}>
        Назад
      </Button>
      <div className="profile__title _h3">Оценки</div>
      <ul className="marks__list">
        {marks.map((e: any, i: number) => (
          <li className="marks__list-item" key={i}>
            <div className="marks__cat">{e.name}</div>
            <ul className="marks__marks">
              <li className="marks__marks-list _top">
                <div className="marks__marks-disciplines">Предмет</div>
                <div className="marks__marks-type">Тип оценки</div>
                <div className="marks__marks-mark">Оценка</div>
              </li>
              {e.marks.map((item: any, index: number) => (
                <li className="marks__marks-list" key={index}>
                  <div className="marks__marks-disciplines">{item.discipline.name}</div>
                  <div className="marks__marks-type">
                    {item.type === "Exam" && "Экзамен"}
                    {item.type === "Test" && "Зачет"}
                    {item.type === "TestWithMark" && "Диф. зачет"}
                  </div>
                  <div className="marks__marks-mark">
                    {item?.type === "Test" ? <>{item?.percent > 3 ? "Зачет" : "Не зачет"}</> : item?.percent}
                  </div>
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MarksList;
