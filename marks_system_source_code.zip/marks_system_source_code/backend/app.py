from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware


App = FastAPI()

origins = ["http://localhost:3000",
           "http://localhost:3050",
	   "http://109.71.242.50",
	   "http://lkstudsiit.ru"]

App.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)
