import React, { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { Navigate, Outlet, useLocation } from "react-router-dom";
import { LOGIN_PATH } from "../../utils/const";
import Aside from "../Aside/Aside";
import { setIsShowMenu } from "../../store/appReducer";

const App = () => {
  const isAuth = useAppSelector((state) => state.auth.isAuth);
  const location = useLocation();

  const dispatch = useAppDispatch();

  useEffect(() => {
    dispatch(setIsShowMenu(false));
    document.getElementById("body")?.classList.remove("_fixed");
  }, [location]);

  if (!isAuth) {
    return <Navigate to={LOGIN_PATH} replace={true} />;
  }


  return (
    <>
      <div className="main__inner container">
        <Aside />
        <Outlet />
      </div>
    </>
  );
};

export default App;
