import React, { useEffect } from "react";
import { Navigate, useNavigate, useParams } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import { deleteUserThunk, getUser } from "../../../store/userReducer";
import { getGroups } from "../../../store/groupReducer";
import { SubmitHandler, useForm } from "react-hook-form";
import { openErrorNotification, openSuccessNotification } from "../../../utils/Notification";
import { authAPI } from "../../../api/api";
import SelectInputMulti from "../../UI/SelectMulti";
import { Button, Modal } from "antd";
import SelectInput from "../../UI/Select";
import { requiredField } from "../../../utils/validators/validators";
import { ExclamationCircleFilled } from "@ant-design/icons";
import { USERS_PATH } from "../../../utils/const";

type Inputs = {
  login: string;
  password: string;
  fullname: string;
  user_type: number;
  groups_ids: Array<number>;
};

const UsersEdit = () => {
  const user = useAppSelector((state) => state.users.user);
  const groups = useAppSelector((state) => state.groups.listGroup);

  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const { confirm } = Modal;

  const params = useParams<{ id: string }>();

  const groupsForInput = groups.map((e: { id: number; name: string }) => ({
    value: e.id,
    label: e.name,
  }));

  const {
    register,
    handleSubmit,
    control,
    reset,
    formState: { errors },
  } = useForm<Inputs>();

  const onSubmit: SubmitHandler<Inputs> = async (dataForm) => {
    try {
      console.log(dataForm);
      const { data } = await authAPI.update(dataForm, Number(params.id));
      openSuccessNotification("Успешное обновление пользователя");
      dispatch(getUser(Number(params.id)));
      dispatch(getGroups());
    } catch (e: any) {
      console.error(e);
      openErrorNotification("Ошибка обновления пользователя");
    }
  };

  const onDelete = () => {
    confirm({
      title: "Вы уверены что хотите удалить?",
      icon: <ExclamationCircleFilled />,
      content: "Данный пользователь будет удален",
      onOk() {
        dispatch(deleteUserThunk(Number(params.id)));
        navigate(-1);
      },
      okText: "Удалить",
      okType: "danger",
      cancelText: "Отмена",
    });
  };

  useEffect(() => {
    if (user && user.login) {
      reset({
        login: user.login,
        user_type: user.user_type,
        fullname: user.fullname,
        groups_ids: user.groups.map((e: any) => e.id),
      });
    }
  }, [user, groups]);

  useEffect(() => {
    dispatch(getUser(Number(params.id)));
    dispatch(getGroups());

    return () => {
      dispatch(getUser());
    };
  }, []);

  if (user?.user_type === 2) {
    return <Navigate to={USERS_PATH} />;
  }

  return (
    <div className="profile">
      <Button className="profile__top-btn" onClick={() => navigate(-1)}>
        К списку пользователей
      </Button>
      <div className="profile__title _h3">Редактирование пользователя</div>

      <section className="login">
        <div className="container">
          <form className="login__wrap">
            <div className="login__inner">
              <div className="login__input-wrap input">
                <label className="input__label" htmlFor="name">
                  Имя*
                </label>
                <input
                  {...register("login", requiredField)}
                  className="input__input"
                  type="text"
                  placeholder="Логин"
                  id="name"
                />
                {errors.login && <div className="input__error">{errors.login.message}</div>}
              </div>
              <div className="login__input-wrap input">
                <label className="input__label" htmlFor="pass">
                  Новый пароль*
                </label>
                <input
                  {...register("password", requiredField)}
                  className="input__input"
                  type="password"
                  placeholder="Пароль"
                  id="pass"
                />
                {errors.password && <div className="input__error">{errors.password.message}</div>}
              </div>
              <div className="login__input-wrap input">
                <label className="input__label" htmlFor="fullname">
                  Полное имя*
                </label>
                <input
                  {...register("fullname", requiredField)}
                  className="input__input"
                  type="text"
                  placeholder="Полное имя"
                  id="fullname"
                />
                {errors.fullname && <div className="input__error">{errors.fullname.message}</div>}
              </div>
              <div className="login__input-wrap input">
                <label className="input__label" htmlFor="user_type">
                  Тип пользователя*
                </label>

                <SelectInput
                  data={[
                    { value: 0, label: "Студент" },
                    { value: 1, label: "Учитель" },
                  ]}
                  name="user_type"
                  control={control}
                />

                {errors.user_type && <div className="input__error">{errors.user_type.message}</div>}
              </div>
              <div className="login__input-wrap input">
                <label className="input__label" htmlFor="groups_ids">
                  Группы*
                </label>

                <SelectInputMulti data={groupsForInput} name="groups_ids" control={control} />

                {errors.groups_ids && <div className="input__error">{errors.groups_ids.message}</div>}
              </div>
            </div>
            <Button className="login__btn" type="primary" onClick={handleSubmit(onSubmit)}>
              Обновить
            </Button>
          </form>
        </div>
      </section>
      <Button style={{ marginTop: "20px" }} onClick={onDelete} danger>
        Удалить пользователя
      </Button>
    </div>
  );
};

export default UsersEdit;
