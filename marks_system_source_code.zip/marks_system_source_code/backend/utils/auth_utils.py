from typing import Type, Optional

import jwt
from sqlalchemy.orm import Session

import models

from fastapi import Request


def make_token(user: Type[models.User] | models.User) -> str:
    encoded_jwt = jwt.encode({"user_id": user.id}, "secret", algorithm="HS256")

    return encoded_jwt


def decode_token(encoded_jwt: str) -> dict:
    return jwt.decode(encoded_jwt, "secret", algorithms=["HS256"])


def get_user_id_by_request(request: Request) -> Optional[int]:
    token = request.cookies.get('token')

    if token is None:
        return None

    try:
        decoded_jwt = jwt.decode(token, "secret", algorithms=["HS256"])

        return decoded_jwt['user_id']
    except jwt.ExpiredSignatureError:
        return None


def get_user_by_id(user_id: Optional[int]) -> Optional[models.User | Type[models.User]]:
    session = Session(bind=models.engine)

    if user_id is None:
        return None

    user = session.query(models.User).filter(models.User.id == user_id).first()

    if user is None:
        return None
    else:
        session.expunge(user)

        session.close()

        return user


def get_user_by_request(request: Request):
    user_id = get_user_id_by_request(request)

    return get_user_by_id(user_id)
