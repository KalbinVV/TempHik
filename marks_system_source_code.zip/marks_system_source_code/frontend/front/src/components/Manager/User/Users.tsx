import { Button, Table, TableColumnsType } from "antd";
import React, { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "../../../store/hooks";
import { USERS_ADD_PATH, typeAppMobile } from "../../../utils/const";
import { Link, useNavigate } from "react-router-dom";
import { getUsers } from "../../../store/userReducer";
import { LinkOutlined } from "@ant-design/icons";

interface DataType {
  id: number;
  name: string;
  userType: number;
  groups: Array<any>;
  login: string;
}

const Users = () => {
  const users = useAppSelector((state) => state.users.listUsers);

  const dispatch = useAppDispatch();
  const isMob = useAppSelector((state) => state.app.typeApp);

  const navigate = useNavigate();

  const columns: TableColumnsType<DataType> = [
    {
      title: "Имя",
      key: "name",
      render: (a) => <Link to={`${a.id}`}>{a.name}</Link>,
    },
    {
      title: "Логин",
      key: "login",
      dataIndex: "login",
    },
    {
      title: "Тип",
      key: "userType",
      render: (a) => (
        <div>
          {a.userType === 0 && "Студент"}
          {a.userType === 1 && "Преподователь"}
          {a.userType === 2 && "Администратор"}
        </div>
      ),
    },
    {
      title: "Управление",
      key: "userType",
      render: (a) => (
        <div className="table__inner">
          <Button
            onClick={() => navigate(`${a.id}`)}
            className="table__btn _green"
          >
           <LinkOutlined />
          </Button>
        </div>
      ),
    },
  ];

  useEffect(() => {
    dispatch(getUsers());
  }, []);

  return (
    <div className="profile">
      {isMob === typeAppMobile && (
        <Button className="profile__top-btn" onClick={() => navigate(-1)}>
          Назад
        </Button>
      )}
      <div className="profile__title _h3">Управления пользователями</div>

      <Link className="btn" to={USERS_ADD_PATH}>
        Добавить пользователя
      </Link>

    
      <Table className="profile__table" dataSource={users} columns={columns} pagination={false} />
    </div>
  );
};

export default Users;
