const Error = () => {
  return (
    <section className="notFound">
      <div>404</div>
      <span>Страница не найдена</span>
    </section>
  );
};

export default Error;
