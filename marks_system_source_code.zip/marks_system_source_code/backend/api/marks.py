from typing import Annotated, NoReturn

from sqlalchemy.orm import Session

import models
from app import App
from decorators.auth_decorators import auth_required
from decorators.security_decorators import privilege_level_required

from fastapi import Request, Body, HTTPException

from utils.auth_utils import get_user_id_by_request
from utils.marks_utils import get_dict_from_mark_model


@App.post('/marks/mark',
          summary=['Добавить или обновить оценку'],
          tags=['Оценки'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def set_user_mark(_request: Request,
                  user_id: Annotated[int, Body()],
                  group_id: Annotated[int, Body()],
                  discipline_id: Annotated[int, Body()],
                  category_id: Annotated[int, Body()],
                  mark_type: Annotated[models.DisciplineMarkType, Body()],
                  percent: Annotated[float, Body()]):
    with Session(models.engine) as session:
        def _raise_exception_if_not_exists(entity, entity_id, detail) -> NoReturn | None:
            found_entity = session.query(entity).get(entity_id)

            if not found_entity:
                raise HTTPException(status_code=400,
                                    detail=detail)

        _raise_exception_if_not_exists(models.User, user_id, 'Неправильный ID пользователя!')
        _raise_exception_if_not_exists(models.Group, group_id, 'Неправильный ID группы!')
        _raise_exception_if_not_exists(models.Discipline, discipline_id, 'Неправильный ID дисциплины!')
        _raise_exception_if_not_exists(models.Category, category_id, 'Неправильный ID категории!')

        mark = session.query(models.DisciplineMark).filter_by(user_id=user_id,
                                                              group_id=group_id,
                                                              discipline_id=discipline_id,
                                                              category_id=category_id).first()

        if mark is None:
            mark = models.DisciplineMark(user_id=user_id,
                                         group_id=group_id,
                                         discipline_id=discipline_id,
                                         category_id=category_id,
                                         percent=percent,
                                         type=mark_type)

            session.add(mark)
        else:
            mark.percent = percent
            mark.type = mark_type

        session.commit()

        return {'mark_id': mark.id}


@App.put('/marks/remove_mark',
         summary='Удалить оценку',
         tags=['Оценки'])
@privilege_level_required(minimal_level=models.UserType.Admin)
def remove_mark(_request: Request,
                mark_id: Annotated[int, Body()]):
    with Session(models.engine) as session:
        session.query(models.DisciplineMark).filter_by(id=mark_id).delete()

        session.commit()

        return {'ok': True}


def get_user_marks(user_id: int, group_id: int):
    with Session(models.engine) as session:
        user = session.query(models.User).get(user_id)

        if user is None:
            raise HTTPException(status_code=404,
                                detail='Неправильный ID пользователя!')

        user_group = session.query(models.Group).get(group_id)

        if not user_group:
            raise HTTPException(status_code=404,
                                detail='Неправильный ID группы!')

        user_marks_list = list()

        for category in user_group.categories:
            marks = session.query(models.DisciplineMark).filter_by(user_id=user_id,
                                                                   category_id=category.id).all()

            user_marks_list.append({'name': category.name,
                                    'id': category.id,
                                    'marks': [get_dict_from_mark_model(mark) for mark in marks]})

        return user_marks_list


@App.get('/marks/user_marks',
         summary='Получить оценки студента',
         tags=['Оценки'])
@privilege_level_required(minimal_level=models.UserType.Teacher)
def get_another_user_marks(_request: Request,
                           user_id: int,
                           group_id: int):
    return get_user_marks(user_id, group_id)


@App.get('/marks/my_marks',
         summary='Получить свои оценки',
         tags=['Оценки'])
@auth_required
def get_my_marks(request: Request, group_id: int):
    user_id = get_user_id_by_request(request)

    return get_user_marks(user_id, group_id)
