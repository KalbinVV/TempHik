import React from "react";
import { NavLink } from "react-router-dom";
import { MAIN_PATH, MANAGER_PATH, MARKS_PATH } from "../../utils/const";
import { useAppDispatch, useAppSelector } from "../../store/hooks";
import { Button } from "antd";
import { CloseOutlined } from "@ant-design/icons";
import { setIsShowMenu } from "../../store/appReducer";

const Aside = () => {

  const dispatch = useAppDispatch();
  const typeUser = useAppSelector((state) => state.auth.userType);
  const isShowMenu = useAppSelector((state) => state.app.showMenu);

  const onCloseMenu = () =>{
    dispatch(setIsShowMenu(false));
    document.getElementById('body')?.classList.remove('_fixed')
  }

  return (
    <aside className={`aside ${isShowMenu ? "_open" : ""}`}>
      <Button onClick={onCloseMenu} icon={<CloseOutlined />} className="aside__menu-btn"></Button>
      <ul className="aside__list">
        <li className="aside__item">
          <NavLink className={"aside__link"} to={MAIN_PATH}>
            Профиль
          </NavLink>
        </li>
        {typeUser === 2 && (
          <li className="aside__item">
            <NavLink className={"aside__link"} to={MANAGER_PATH}>
              Управление
            </NavLink>
          </li>
        )}
        <li className="aside__item">
          <NavLink className={"aside__link"} to={MARKS_PATH}>
            Оценки
          </NavLink>
        </li>
      </ul>
    </aside>
  );
};

export default Aside;
